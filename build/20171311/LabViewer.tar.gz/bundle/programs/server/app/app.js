var require = meteorInstall({"imports":{"api":{"server":{"getData.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/server/getData.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Obs;
module.watch(require("../Observations.js"), {
	Obs(v) {
		Obs = v;
	}

}, 0);
Meteor.methods({
	'getPatients': function (endpoint) {
		// first, drop any old observations from the collection 
		Meteor.call('resetDB');
		patientEndpoint = endpoint + '/Patient';

		try {
			res = HTTP.call('GET', patientEndpoint, {
				params: {
					_count: 40 //Just get the first x patients (default I think is 100)

				},
				headers: {
					Accept: 'application/json, application/json+fhir'
				}
			}); //If there are no errors, we will end up here
			// First, see if the response got returned as data. Most servers do, but SmartHealthIT does not. If res.data is blank, we will have to convert the content (text string but should be JSON) into an object

			try {
				// use try/catch because if the content is not JSON it will fail. 
				if (!res.data) {
					res.data = JSON.parse(res.content);
				}
			} catch (e) {
				console.log(e); // if the server throws an error, we just return "no patients found"
			} // This will return a resource "bundle" which is an array of resources that match the search
			// Since we specifically searched for "Patient" all the resources are patients. 
			// Now, we only really need the Name and ID from here. Later we could pull more info. 
			// So, lets build a simple object with a list of patient names and ID's to return to the client.
			// This will need to be in the same format as our patList on the client code
			/* eg: 
   patList = [
   	{ name: 'name', id: 'id' }
   ]
   */ // First let's initialize the array- 


			patList = []; // If we get real data but no results we should return an array with a "no patients returned" message

			if (!res.data.entry) {
				patList.push({
					name: 'No patients found!',
					id: ''
				});
				return patList; // Then we just return this and thus stop here.
			} // Else, we will need to do a loop to populate this new array with things from each of the results
			//see for example: https://www.w3schools.com/js/js_loop_for.asp
			//console.dir(res.data.entry)


			for (x in res.data.entry) {
				//	console.log(res.data.entry[x].resource.name[0].given)
				var pre = res.data.entry[x].resource; // for simplicity

				try {
					// check if name exists in the result (otherwise push will error)
					patList.push({
						// the name data is unfortunately deeply nested in the FHIR object and is itself in another array. For simplicity we will just select the first given and first family names, and combine these with a space into a common "name" field
						name: pre.name[0].given + ' ' + pre.name[0].family,
						// the id is thankfully a top-level object in the resource
						id: pre.id,
						// we can also throw in sex and age in here to help set context. 
						birthDate: pre.birthDate,
						gender: pre.gender
					});
				} catch (e) {
					// Sometimes results won't have a valid name. we'll just basically ignore these errors and they simply won't make it into the patList array
					console.log('entry ' + x + ' found no valid name. Skipping.'); //console.log(e)
				}
			} // Finally, return this array to the client. 


			return patList;
		} catch (e) {
			//console.log(e)
			// if the server throws crap, we just return:
			patList.push({
				name: 'No patients found!',
				id: ''
			});
			return patList; // and thus stop here.
		}
	},
	'getObservations': function (endpoint, patId) {
		// first, drop any old observations from the collection 
		Meteor.call('resetDB');
		ObsEndpoint = endpoint + '/Observation';

		try {
			res = HTTP.call('GET', ObsEndpoint, {
				params: {
					patient: patId //category: 'laboratory' // hard-code this to just return laboratory data
					//category: 'vital-signs' //

				},
				headers: {
					Accept: 'application/json, application/json+fhir'
				}
			}); // console.dir(res)

			try {
				// use try/catch because if the content is not JSON it will fail. 
				if (!res.data) {
					res.data = JSON.parse(res.content);
				}
			} catch (e) {
				console.log(e);
			}

			results = [];

			if (!res.data.entry) {
				// if no data gracefully return zero results.
				results.push({});
				return results;
			} //return { results: res.data.entry.length, entries: res.data.entry } 
			// The fhir-formatted data is ugly and hard to parse through on client-side helpers.
			// For simplicity, we will go ahead and parse out the data we want for this particular patient, and pass the simpler, cleaner object to the client.
			// This is similar to how we handle the patient search above


			for (x in res.data.entry) {
				pre = res.data.entry[x].resource; //Use a try/catch so we don't just crash

				try {
					if (pre.valueQuantity.value) {
						// if there is an individual value, we will use that
						results.push({
							codeName: pre.code.coding[0].display,
							code: pre.code.coding[0].code,
							value: pre.valueQuantity.value,
							// need to trim this to 2 decimal places, otherwise looks crappy.
							dateTime: new Date(pre.effectiveDateTime) // endpoint: endpoint,
							// patId: patId

						});
					} else {// if there is not an individual value (like a BP) we need to do more logic...
						// for now just do nothing
					}
				} catch (e) {
					console.log(e); // Some results will not have a single value (blood pressures) and will end up here. Since we are looking at labs we don't care. Just log and move on.
					//console.log('no value for entry '+x+' - '+pre.code.coding[0].display)
				}
			}

			return results;
		} catch (e) {
			console.log(e); // handle 401 (not authroized) here
		}
	}
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/Observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Obs: () => Obs
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
const Obs = new Mongo.Collection(null);
// change this to a local collection only (no DB, but still get Mongo functionality!)
Meteor.methods({
    'resetDB': function () {
        // drop everything
        Obs.remove({});
    }
}); /*
    if (Meteor.isServer) {
    	Meteor.publish('obs', function () {
    		return Obs.find({}) // how we publish codes to the client. For now, just return everything. 
    	})
    
    
    if (Meteor.isClient) {
        Meteor.subscribe('obs') // Makes the collection available to the client (Templates and stuff)
    };
    
    
    */
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.watch(require("../imports/api/server/getData.js"));
//import { Obs } from '../imports/api/Observations.js'
Meteor.startup(() => {// code to run on server at startup
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2VydmVyL2dldERhdGEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL09ic2VydmF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiT2JzIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1ldGVvciIsIm1ldGhvZHMiLCJlbmRwb2ludCIsImNhbGwiLCJwYXRpZW50RW5kcG9pbnQiLCJyZXMiLCJIVFRQIiwicGFyYW1zIiwiX2NvdW50IiwiaGVhZGVycyIsIkFjY2VwdCIsImRhdGEiLCJKU09OIiwicGFyc2UiLCJjb250ZW50IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJwYXRMaXN0IiwiZW50cnkiLCJwdXNoIiwibmFtZSIsImlkIiwieCIsInByZSIsInJlc291cmNlIiwiZ2l2ZW4iLCJmYW1pbHkiLCJiaXJ0aERhdGUiLCJnZW5kZXIiLCJwYXRJZCIsIk9ic0VuZHBvaW50IiwicGF0aWVudCIsInJlc3VsdHMiLCJ2YWx1ZVF1YW50aXR5IiwidmFsdWUiLCJjb2RlTmFtZSIsImNvZGUiLCJjb2RpbmciLCJkaXNwbGF5IiwiZGF0ZVRpbWUiLCJEYXRlIiwiZWZmZWN0aXZlRGF0ZVRpbWUiLCJleHBvcnQiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJyZW1vdmUiLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLEdBQUo7QUFBUUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ0gsS0FBSUksQ0FBSixFQUFNO0FBQUNKLFFBQUlJLENBQUo7QUFBTTs7QUFBZCxDQUEzQyxFQUEyRCxDQUEzRDtBQUlSQyxPQUFPQyxPQUFQLENBQWU7QUFDWCxnQkFBZSxVQUFVQyxRQUFWLEVBQW9CO0FBQy9CO0FBQ0FGLFNBQU9HLElBQVAsQ0FBWSxTQUFaO0FBRU5DLG9CQUFrQkYsV0FBVyxVQUE3Qjs7QUFDQSxNQUFJO0FBQ0hHLFNBQU1DLEtBQUtILElBQUwsQ0FDSixLQURJLEVBRUpDLGVBRkksRUFFYTtBQUNoQkcsWUFBUTtBQUNQQyxhQUFRLEVBREQsQ0FDSzs7QUFETCxLQURRO0FBSWhCQyxhQUFTO0FBQ1JDLGFBQVE7QUFEQTtBQUpPLElBRmIsQ0FBTixDQURHLENBWUg7QUFDQTs7QUFFQSxPQUFHO0FBQUU7QUFDSixRQUFJLENBQUNMLElBQUlNLElBQVQsRUFBZTtBQUNkTixTQUFJTSxJQUFKLEdBQVdDLEtBQUtDLEtBQUwsQ0FBV1IsSUFBSVMsT0FBZixDQUFYO0FBQ0E7QUFDRCxJQUpELENBSUUsT0FBT0MsQ0FBUCxFQUFVO0FBQ0NDLFlBQVFDLEdBQVIsQ0FBWUYsQ0FBWixFQURELENBRUM7QUFFWixJQXZCRSxDQXlCSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7S0E5QkcsQ0FtQ0g7OztBQUNBRyxhQUFVLEVBQVYsQ0FwQ0csQ0FzQ0g7O0FBQ0EsT0FBSSxDQUFDYixJQUFJTSxJQUFKLENBQVNRLEtBQWQsRUFBcUI7QUFDcEJELFlBQVFFLElBQVIsQ0FBYTtBQUFFQyxXQUFNLG9CQUFSO0FBQThCQyxTQUFJO0FBQWxDLEtBQWI7QUFDQSxXQUFPSixPQUFQLENBRm9CLENBRUw7QUFDZixJQTFDRSxDQTRDSDtBQUNBO0FBQ0E7OztBQUNBLFFBQUtLLENBQUwsSUFBVWxCLElBQUlNLElBQUosQ0FBU1EsS0FBbkIsRUFBMEI7QUFFekI7QUFDQSxRQUFJSyxNQUFNbkIsSUFBSU0sSUFBSixDQUFTUSxLQUFULENBQWVJLENBQWYsRUFBa0JFLFFBQTVCLENBSHlCLENBR1k7O0FBRXJDLFFBQUk7QUFBRTtBQUVMUCxhQUFRRSxJQUFSLENBQWE7QUFDWjtBQUVBQyxZQUFNRyxJQUFJSCxJQUFKLENBQVMsQ0FBVCxFQUFZSyxLQUFaLEdBQW9CLEdBQXBCLEdBQTBCRixJQUFJSCxJQUFKLENBQVMsQ0FBVCxFQUFZTSxNQUhoQztBQUlaO0FBQ0FMLFVBQUlFLElBQUlGLEVBTEk7QUFNWjtBQUNBTSxpQkFBV0osSUFBSUksU0FQSDtBQVFaQyxjQUFRTCxJQUFJSztBQVJBLE1BQWI7QUFVQSxLQVpELENBWUUsT0FBT2QsQ0FBUCxFQUFVO0FBQ1g7QUFDQUMsYUFBUUMsR0FBUixDQUFZLFdBQVNNLENBQVQsR0FBVyxpQ0FBdkIsRUFGVyxDQUdYO0FBQ0E7QUFDQSxJQXJFQyxDQXVFSDs7O0FBQ0EsVUFBT0wsT0FBUDtBQUVBLEdBMUVELENBMEVFLE9BQU9ILENBQVAsRUFBVTtBQUNYO0FBQ0E7QUFDU0csV0FBUUUsSUFBUixDQUFhO0FBQUVDLFVBQU0sb0JBQVI7QUFBOEJDLFFBQUk7QUFBbEMsSUFBYjtBQUNBLFVBQU9KLE9BQVAsQ0FKRSxDQUlhO0FBQ3hCO0FBQ0QsRUF0RmE7QUF3Rlgsb0JBQW1CLFVBQVVoQixRQUFWLEVBQW9CNEIsS0FBcEIsRUFBMkI7QUFDMUM7QUFDQTlCLFNBQU9HLElBQVAsQ0FBWSxTQUFaO0FBRU40QixnQkFBYzdCLFdBQVcsY0FBekI7O0FBQ0EsTUFBSTtBQUNIRyxTQUFNQyxLQUFLSCxJQUFMLENBQ0osS0FESSxFQUVKNEIsV0FGSSxFQUVTO0FBQ1p4QixZQUFRO0FBQ1B5QixjQUFTRixLQURGLENBRVA7QUFDQTs7QUFITyxLQURJO0FBTVpyQixhQUFTO0FBQ1JDLGFBQVE7QUFEQTtBQU5HLElBRlQsQ0FBTixDQURHLENBYUg7O0FBQ0EsT0FBSTtBQUFFO0FBQ0wsUUFBSSxDQUFDTCxJQUFJTSxJQUFULEVBQWU7QUFDZE4sU0FBSU0sSUFBSixHQUFXQyxLQUFLQyxLQUFMLENBQVdSLElBQUlTLE9BQWYsQ0FBWDtBQUNBO0FBQ0QsSUFKRCxDQUlFLE9BQU9DLENBQVAsRUFBVTtBQUNYQyxZQUFRQyxHQUFSLENBQVlGLENBQVo7QUFDQTs7QUFFUWtCLGFBQVUsRUFBVjs7QUFFQSxPQUFJLENBQUM1QixJQUFJTSxJQUFKLENBQVNRLEtBQWQsRUFBcUI7QUFBRTtBQUNuQmMsWUFBUWIsSUFBUixDQUFhLEVBQWI7QUFDWixXQUFPYSxPQUFQO0FBQ0EsSUEzQkUsQ0E2Qkg7QUFDUztBQUNBO0FBQ0E7OztBQUVBLFFBQUtWLENBQUwsSUFBVWxCLElBQUlNLElBQUosQ0FBU1EsS0FBbkIsRUFBeUI7QUFDckJLLFVBQU1uQixJQUFJTSxJQUFKLENBQVNRLEtBQVQsQ0FBZUksQ0FBZixFQUFrQkUsUUFBeEIsQ0FEcUIsQ0FFckI7O0FBQ0EsUUFBSTtBQUNBLFNBQUdELElBQUlVLGFBQUosQ0FBa0JDLEtBQXJCLEVBQTJCO0FBQUU7QUFDekJGLGNBQVFiLElBQVIsQ0FBYTtBQUNUZ0IsaUJBQVVaLElBQUlhLElBQUosQ0FBU0MsTUFBVCxDQUFnQixDQUFoQixFQUFtQkMsT0FEcEI7QUFFVEYsYUFBTWIsSUFBSWEsSUFBSixDQUFTQyxNQUFULENBQWdCLENBQWhCLEVBQW1CRCxJQUZoQjtBQUdURixjQUFPWCxJQUFJVSxhQUFKLENBQWtCQyxLQUhoQjtBQUd1QjtBQUNoQ0ssaUJBQVUsSUFBSUMsSUFBSixDQUFTakIsSUFBSWtCLGlCQUFiLENBSkQsQ0FLVjtBQUNBOztBQU5VLE9BQWI7QUFRSCxNQVRELE1BU08sQ0FDSDtBQUNBO0FBQ0g7QUFDSixLQWRELENBY0UsT0FBTzNCLENBQVAsRUFBVTtBQUNSQyxhQUFRQyxHQUFSLENBQVlGLENBQVosRUFEUSxDQUVSO0FBQ0E7QUFDSDtBQUVKOztBQUNELFVBQU9rQixPQUFQO0FBQ1QsR0EzREQsQ0EyREUsT0FBT2xCLENBQVAsRUFBVTtBQUNYQyxXQUFRQyxHQUFSLENBQVlGLENBQVosRUFEVyxDQUVYO0FBQ0E7QUFDRTtBQTVKVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkFuQixPQUFPK0MsTUFBUCxDQUFjO0FBQUNoRCxTQUFJLE1BQUlBO0FBQVQsQ0FBZDtBQUE2QixJQUFJaUQsS0FBSjtBQUFVaEQsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDOEMsVUFBTTdDLENBQU4sRUFBUTtBQUFDNkMsZ0JBQU03QyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRWhDLE1BQU1KLE1BQU0sSUFBSWlELE1BQU1DLFVBQVYsQ0FBcUIsSUFBckIsQ0FBWjtBQUF3QztBQUUvQzdDLE9BQU9DLE9BQVAsQ0FBZTtBQUNYLGVBQVcsWUFBWTtBQUFFO0FBQ3JCTixZQUFJbUQsTUFBSixDQUFXLEVBQVg7QUFDSDtBQUhVLENBQWYsRSxDQU1BOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1ZBLElBQUk5QyxNQUFKO0FBQVdKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0UsU0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0RILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQ0FBUixDQUFiO0FBRTFFO0FBQ0FFLE9BQU8rQyxPQUFQLENBQWUsTUFBTSxDQUNuQjtBQUNELENBRkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy9TZXJ2ZXItc2lkZSBvbmx5IG1ldGhvZHMgZm9yIGhhbmRsaW5nIFJFU1QvRkhJUiBhcGkgY2FsbHNcclxuXHJcbmltcG9ydCB7IE9icyB9IGZyb20gJy4uL09ic2VydmF0aW9ucy5qcydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdnZXRQYXRpZW50cyc6IGZ1bmN0aW9uIChlbmRwb2ludCkge1xyXG4gICAgICAgIC8vIGZpcnN0LCBkcm9wIGFueSBvbGQgb2JzZXJ2YXRpb25zIGZyb20gdGhlIGNvbGxlY3Rpb24gXHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ3Jlc2V0REInKVxyXG5cclxuXHRcdHBhdGllbnRFbmRwb2ludCA9IGVuZHBvaW50ICsgJy9QYXRpZW50J1xyXG5cdFx0dHJ5IHtcclxuXHRcdFx0cmVzID0gSFRUUC5jYWxsKFxyXG5cdFx0XHRcdFx0J0dFVCcsXHJcblx0XHRcdFx0XHRwYXRpZW50RW5kcG9pbnQsIHtcclxuXHRcdFx0XHRcdFx0cGFyYW1zOiB7XHJcblx0XHRcdFx0XHRcdFx0X2NvdW50OiA0MCwgLy9KdXN0IGdldCB0aGUgZmlyc3QgeCBwYXRpZW50cyAoZGVmYXVsdCBJIHRoaW5rIGlzIDEwMClcclxuXHRcdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdFx0aGVhZGVyczoge1xyXG5cdFx0XHRcdFx0XHRcdEFjY2VwdDogJ2FwcGxpY2F0aW9uL2pzb24sIGFwcGxpY2F0aW9uL2pzb24rZmhpcidcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fSlcclxuXHJcblx0XHRcdC8vSWYgdGhlcmUgYXJlIG5vIGVycm9ycywgd2Ugd2lsbCBlbmQgdXAgaGVyZVxyXG5cdFx0XHQvLyBGaXJzdCwgc2VlIGlmIHRoZSByZXNwb25zZSBnb3QgcmV0dXJuZWQgYXMgZGF0YS4gTW9zdCBzZXJ2ZXJzIGRvLCBidXQgU21hcnRIZWFsdGhJVCBkb2VzIG5vdC4gSWYgcmVzLmRhdGEgaXMgYmxhbmssIHdlIHdpbGwgaGF2ZSB0byBjb252ZXJ0IHRoZSBjb250ZW50ICh0ZXh0IHN0cmluZyBidXQgc2hvdWxkIGJlIEpTT04pIGludG8gYW4gb2JqZWN0XHJcblxyXG5cdFx0XHR0cnl7IC8vIHVzZSB0cnkvY2F0Y2ggYmVjYXVzZSBpZiB0aGUgY29udGVudCBpcyBub3QgSlNPTiBpdCB3aWxsIGZhaWwuIFxyXG5cdFx0XHRcdGlmICghcmVzLmRhdGEpIHtcclxuXHRcdFx0XHRcdHJlcy5kYXRhID0gSlNPTi5wYXJzZShyZXMuY29udGVudClcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXHJcbiAgICAgICAgICAgICAgICAvLyBpZiB0aGUgc2VydmVyIHRocm93cyBhbiBlcnJvciwgd2UganVzdCByZXR1cm4gXCJubyBwYXRpZW50cyBmb3VuZFwiXHJcblxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQvLyBUaGlzIHdpbGwgcmV0dXJuIGEgcmVzb3VyY2UgXCJidW5kbGVcIiB3aGljaCBpcyBhbiBhcnJheSBvZiByZXNvdXJjZXMgdGhhdCBtYXRjaCB0aGUgc2VhcmNoXHJcblx0XHRcdC8vIFNpbmNlIHdlIHNwZWNpZmljYWxseSBzZWFyY2hlZCBmb3IgXCJQYXRpZW50XCIgYWxsIHRoZSByZXNvdXJjZXMgYXJlIHBhdGllbnRzLiBcclxuXHRcdFx0Ly8gTm93LCB3ZSBvbmx5IHJlYWxseSBuZWVkIHRoZSBOYW1lIGFuZCBJRCBmcm9tIGhlcmUuIExhdGVyIHdlIGNvdWxkIHB1bGwgbW9yZSBpbmZvLiBcclxuXHRcdFx0Ly8gU28sIGxldHMgYnVpbGQgYSBzaW1wbGUgb2JqZWN0IHdpdGggYSBsaXN0IG9mIHBhdGllbnQgbmFtZXMgYW5kIElEJ3MgdG8gcmV0dXJuIHRvIHRoZSBjbGllbnQuXHJcblx0XHRcdC8vIFRoaXMgd2lsbCBuZWVkIHRvIGJlIGluIHRoZSBzYW1lIGZvcm1hdCBhcyBvdXIgcGF0TGlzdCBvbiB0aGUgY2xpZW50IGNvZGVcclxuXHRcdFx0LyogZWc6IFxyXG5cdFx0XHRwYXRMaXN0ID0gW1xyXG5cdFx0XHRcdHsgbmFtZTogJ25hbWUnLCBpZDogJ2lkJyB9XHJcblx0XHRcdF1cclxuXHRcdFx0Ki9cclxuXHRcdFx0Ly8gRmlyc3QgbGV0J3MgaW5pdGlhbGl6ZSB0aGUgYXJyYXktIFxyXG5cdFx0XHRwYXRMaXN0ID0gW11cclxuXHJcblx0XHRcdC8vIElmIHdlIGdldCByZWFsIGRhdGEgYnV0IG5vIHJlc3VsdHMgd2Ugc2hvdWxkIHJldHVybiBhbiBhcnJheSB3aXRoIGEgXCJubyBwYXRpZW50cyByZXR1cm5lZFwiIG1lc3NhZ2VcclxuXHRcdFx0aWYgKCFyZXMuZGF0YS5lbnRyeSkge1xyXG5cdFx0XHRcdHBhdExpc3QucHVzaCh7IG5hbWU6ICdObyBwYXRpZW50cyBmb3VuZCEnLCBpZDogJycgfSlcclxuXHRcdFx0XHRyZXR1cm4gcGF0TGlzdCAvLyBUaGVuIHdlIGp1c3QgcmV0dXJuIHRoaXMgYW5kIHRodXMgc3RvcCBoZXJlLlxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQvLyBFbHNlLCB3ZSB3aWxsIG5lZWQgdG8gZG8gYSBsb29wIHRvIHBvcHVsYXRlIHRoaXMgbmV3IGFycmF5IHdpdGggdGhpbmdzIGZyb20gZWFjaCBvZiB0aGUgcmVzdWx0c1xyXG5cdFx0XHQvL3NlZSBmb3IgZXhhbXBsZTogaHR0cHM6Ly93d3cudzNzY2hvb2xzLmNvbS9qcy9qc19sb29wX2Zvci5hc3BcclxuXHRcdFx0Ly9jb25zb2xlLmRpcihyZXMuZGF0YS5lbnRyeSlcclxuXHRcdFx0Zm9yICh4IGluIHJlcy5kYXRhLmVudHJ5KSB7XHJcblx0XHRcdFx0XHJcblx0XHRcdFx0Ly9cdGNvbnNvbGUubG9nKHJlcy5kYXRhLmVudHJ5W3hdLnJlc291cmNlLm5hbWVbMF0uZ2l2ZW4pXHJcblx0XHRcdFx0dmFyIHByZSA9IHJlcy5kYXRhLmVudHJ5W3hdLnJlc291cmNlIC8vIGZvciBzaW1wbGljaXR5XHJcblxyXG5cdFx0XHRcdHRyeSB7IC8vIGNoZWNrIGlmIG5hbWUgZXhpc3RzIGluIHRoZSByZXN1bHQgKG90aGVyd2lzZSBwdXNoIHdpbGwgZXJyb3IpXHJcblxyXG5cdFx0XHRcdFx0cGF0TGlzdC5wdXNoKHtcclxuXHRcdFx0XHRcdFx0Ly8gdGhlIG5hbWUgZGF0YSBpcyB1bmZvcnR1bmF0ZWx5IGRlZXBseSBuZXN0ZWQgaW4gdGhlIEZISVIgb2JqZWN0IGFuZCBpcyBpdHNlbGYgaW4gYW5vdGhlciBhcnJheS4gRm9yIHNpbXBsaWNpdHkgd2Ugd2lsbCBqdXN0IHNlbGVjdCB0aGUgZmlyc3QgZ2l2ZW4gYW5kIGZpcnN0IGZhbWlseSBuYW1lcywgYW5kIGNvbWJpbmUgdGhlc2Ugd2l0aCBhIHNwYWNlIGludG8gYSBjb21tb24gXCJuYW1lXCIgZmllbGRcclxuXHJcblx0XHRcdFx0XHRcdG5hbWU6IHByZS5uYW1lWzBdLmdpdmVuICsgJyAnICsgcHJlLm5hbWVbMF0uZmFtaWx5LFxyXG5cdFx0XHRcdFx0XHQvLyB0aGUgaWQgaXMgdGhhbmtmdWxseSBhIHRvcC1sZXZlbCBvYmplY3QgaW4gdGhlIHJlc291cmNlXHJcblx0XHRcdFx0XHRcdGlkOiBwcmUuaWQsXHJcblx0XHRcdFx0XHRcdC8vIHdlIGNhbiBhbHNvIHRocm93IGluIHNleCBhbmQgYWdlIGluIGhlcmUgdG8gaGVscCBzZXQgY29udGV4dC4gXHJcblx0XHRcdFx0XHRcdGJpcnRoRGF0ZTogcHJlLmJpcnRoRGF0ZSxcclxuXHRcdFx0XHRcdFx0Z2VuZGVyOiBwcmUuZ2VuZGVyXHJcblx0XHRcdFx0XHR9KVxyXG5cdFx0XHRcdH0gY2F0Y2ggKGUpIHtcclxuXHRcdFx0XHRcdC8vIFNvbWV0aW1lcyByZXN1bHRzIHdvbid0IGhhdmUgYSB2YWxpZCBuYW1lLiB3ZSdsbCBqdXN0IGJhc2ljYWxseSBpZ25vcmUgdGhlc2UgZXJyb3JzIGFuZCB0aGV5IHNpbXBseSB3b24ndCBtYWtlIGl0IGludG8gdGhlIHBhdExpc3QgYXJyYXlcclxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKCdlbnRyeSAnK3grJyBmb3VuZCBubyB2YWxpZCBuYW1lLiBTa2lwcGluZy4nKVxyXG5cdFx0XHRcdFx0Ly9jb25zb2xlLmxvZyhlKVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHQvLyBGaW5hbGx5LCByZXR1cm4gdGhpcyBhcnJheSB0byB0aGUgY2xpZW50LiBcclxuXHRcdFx0cmV0dXJuIHBhdExpc3RcclxuXHJcblx0XHR9IGNhdGNoIChlKSB7XHJcblx0XHRcdC8vY29uc29sZS5sb2coZSlcclxuXHRcdFx0Ly8gaWYgdGhlIHNlcnZlciB0aHJvd3MgY3JhcCwgd2UganVzdCByZXR1cm46XHJcbiAgICAgICAgICAgIHBhdExpc3QucHVzaCh7IG5hbWU6ICdObyBwYXRpZW50cyBmb3VuZCEnLCBpZDogJycgfSlcclxuICAgICAgICAgICAgcmV0dXJuIHBhdExpc3QgLy8gYW5kIHRodXMgc3RvcCBoZXJlLlxyXG5cdFx0fVxyXG5cdH0sXHJcblxyXG4gICAgJ2dldE9ic2VydmF0aW9ucyc6IGZ1bmN0aW9uIChlbmRwb2ludCwgcGF0SWQpIHtcclxuICAgICAgICAvLyBmaXJzdCwgZHJvcCBhbnkgb2xkIG9ic2VydmF0aW9ucyBmcm9tIHRoZSBjb2xsZWN0aW9uIFxyXG4gICAgICAgIE1ldGVvci5jYWxsKCdyZXNldERCJylcclxuXHJcblx0XHRPYnNFbmRwb2ludCA9IGVuZHBvaW50ICsgJy9PYnNlcnZhdGlvbidcclxuXHRcdHRyeSB7XHJcblx0XHRcdHJlcyA9IEhUVFAuY2FsbChcclxuXHRcdFx0XHRcdCdHRVQnLFxyXG5cdFx0XHRcdFx0T2JzRW5kcG9pbnQsIHtcclxuXHRcdFx0XHRcdFx0cGFyYW1zOiB7XHJcblx0XHRcdFx0XHRcdFx0cGF0aWVudDogcGF0SWQsXHJcblx0XHRcdFx0XHRcdFx0Ly9jYXRlZ29yeTogJ2xhYm9yYXRvcnknIC8vIGhhcmQtY29kZSB0aGlzIHRvIGp1c3QgcmV0dXJuIGxhYm9yYXRvcnkgZGF0YVxyXG5cdFx0XHRcdFx0XHRcdC8vY2F0ZWdvcnk6ICd2aXRhbC1zaWducycgLy9cclxuXHRcdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdFx0aGVhZGVyczoge1xyXG5cdFx0XHRcdFx0XHRcdEFjY2VwdDogJ2FwcGxpY2F0aW9uL2pzb24sIGFwcGxpY2F0aW9uL2pzb24rZmhpcidcclxuXHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0fSlcclxuXHRcdFx0Ly8gY29uc29sZS5kaXIocmVzKVxyXG5cdFx0XHR0cnkgeyAvLyB1c2UgdHJ5L2NhdGNoIGJlY2F1c2UgaWYgdGhlIGNvbnRlbnQgaXMgbm90IEpTT04gaXQgd2lsbCBmYWlsLiBcclxuXHRcdFx0XHRpZiAoIXJlcy5kYXRhKSB7XHJcblx0XHRcdFx0XHRyZXMuZGF0YSA9IEpTT04ucGFyc2UocmVzLmNvbnRlbnQpXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9IGNhdGNoIChlKSB7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coZSlcclxuXHRcdFx0fVxyXG5cclxuICAgICAgICAgICAgcmVzdWx0cyA9IFtdXHJcblxyXG4gICAgICAgICAgICBpZiAoIXJlcy5kYXRhLmVudHJ5KSB7IC8vIGlmIG5vIGRhdGEgZ3JhY2VmdWxseSByZXR1cm4gemVybyByZXN1bHRzLlxyXG4gICAgICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHt9KVxyXG5cdFx0XHRcdHJldHVybiByZXN1bHRzXHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC8vcmV0dXJuIHsgcmVzdWx0czogcmVzLmRhdGEuZW50cnkubGVuZ3RoLCBlbnRyaWVzOiByZXMuZGF0YS5lbnRyeSB9IFxyXG4gICAgICAgICAgICAvLyBUaGUgZmhpci1mb3JtYXR0ZWQgZGF0YSBpcyB1Z2x5IGFuZCBoYXJkIHRvIHBhcnNlIHRocm91Z2ggb24gY2xpZW50LXNpZGUgaGVscGVycy5cclxuICAgICAgICAgICAgLy8gRm9yIHNpbXBsaWNpdHksIHdlIHdpbGwgZ28gYWhlYWQgYW5kIHBhcnNlIG91dCB0aGUgZGF0YSB3ZSB3YW50IGZvciB0aGlzIHBhcnRpY3VsYXIgcGF0aWVudCwgYW5kIHBhc3MgdGhlIHNpbXBsZXIsIGNsZWFuZXIgb2JqZWN0IHRvIHRoZSBjbGllbnQuXHJcbiAgICAgICAgICAgIC8vIFRoaXMgaXMgc2ltaWxhciB0byBob3cgd2UgaGFuZGxlIHRoZSBwYXRpZW50IHNlYXJjaCBhYm92ZVxyXG5cclxuICAgICAgICAgICAgZm9yICh4IGluIHJlcy5kYXRhLmVudHJ5KXtcclxuICAgICAgICAgICAgICAgIHByZSA9IHJlcy5kYXRhLmVudHJ5W3hdLnJlc291cmNlXHJcbiAgICAgICAgICAgICAgICAvL1VzZSBhIHRyeS9jYXRjaCBzbyB3ZSBkb24ndCBqdXN0IGNyYXNoXHJcbiAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKHByZS52YWx1ZVF1YW50aXR5LnZhbHVlKXsgLy8gaWYgdGhlcmUgaXMgYW4gaW5kaXZpZHVhbCB2YWx1ZSwgd2Ugd2lsbCB1c2UgdGhhdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRzLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZU5hbWU6IHByZS5jb2RlLmNvZGluZ1swXS5kaXNwbGF5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29kZTogcHJlLmNvZGUuY29kaW5nWzBdLmNvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogcHJlLnZhbHVlUXVhbnRpdHkudmFsdWUsIC8vIG5lZWQgdG8gdHJpbSB0aGlzIHRvIDIgZGVjaW1hbCBwbGFjZXMsIG90aGVyd2lzZSBsb29rcyBjcmFwcHkuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRlVGltZTogbmV3IERhdGUocHJlLmVmZmVjdGl2ZURhdGVUaW1lKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZW5kcG9pbnQ6IGVuZHBvaW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBwYXRJZDogcGF0SWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGVyZSBpcyBub3QgYW4gaW5kaXZpZHVhbCB2YWx1ZSAobGlrZSBhIEJQKSB3ZSBuZWVkIHRvIGRvIG1vcmUgbG9naWMuLi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZm9yIG5vdyBqdXN0IGRvIG5vdGhpbmdcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcclxuICAgICAgICAgICAgICAgICAgICAvLyBTb21lIHJlc3VsdHMgd2lsbCBub3QgaGF2ZSBhIHNpbmdsZSB2YWx1ZSAoYmxvb2QgcHJlc3N1cmVzKSBhbmQgd2lsbCBlbmQgdXAgaGVyZS4gU2luY2Ugd2UgYXJlIGxvb2tpbmcgYXQgbGFicyB3ZSBkb24ndCBjYXJlLiBKdXN0IGxvZyBhbmQgbW92ZSBvbi5cclxuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKCdubyB2YWx1ZSBmb3IgZW50cnkgJyt4KycgLSAnK3ByZS5jb2RlLmNvZGluZ1swXS5kaXNwbGF5KVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0c1xyXG5cdFx0fSBjYXRjaCAoZSkge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhlKVxyXG5cdFx0XHQvLyBoYW5kbGUgNDAxIChub3QgYXV0aHJvaXplZCkgaGVyZVxyXG5cdFx0fVxyXG4gICAgfSwgICBcclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcblxyXG5leHBvcnQgY29uc3QgT2JzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24obnVsbCk7IC8vIGNoYW5nZSB0aGlzIHRvIGEgbG9jYWwgY29sbGVjdGlvbiBvbmx5IChubyBEQiwgYnV0IHN0aWxsIGdldCBNb25nbyBmdW5jdGlvbmFsaXR5ISlcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdyZXNldERCJzogZnVuY3Rpb24gKCkgeyAvLyBkcm9wIGV2ZXJ5dGhpbmdcclxuICAgICAgICBPYnMucmVtb3ZlKHt9KVxyXG4gICAgfVxyXG59KVxyXG5cclxuLypcclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdE1ldGVvci5wdWJsaXNoKCdvYnMnLCBmdW5jdGlvbiAoKSB7XHJcblx0XHRyZXR1cm4gT2JzLmZpbmQoe30pIC8vIGhvdyB3ZSBwdWJsaXNoIGNvZGVzIHRvIHRoZSBjbGllbnQuIEZvciBub3csIGp1c3QgcmV0dXJuIGV2ZXJ5dGhpbmcuIFxyXG5cdH0pXHJcblxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnb2JzJykgLy8gTWFrZXMgdGhlIGNvbGxlY3Rpb24gYXZhaWxhYmxlIHRvIHRoZSBjbGllbnQgKFRlbXBsYXRlcyBhbmQgc3R1ZmYpXHJcbn07XHJcblxyXG5cclxuKi8iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9zZXJ2ZXIvZ2V0RGF0YS5qcydcbi8vaW1wb3J0IHsgT2JzIH0gZnJvbSAnLi4vaW1wb3J0cy9hcGkvT2JzZXJ2YXRpb25zLmpzJ1xuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxufSk7XG4iXX0=
