var require = meteorInstall({"imports":{"api":{"server":{"getData.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/server/getData.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Obs;
module.watch(require("../Observations.js"), {
	Obs(v) {
		Obs = v;
	}

}, 0);
Meteor.methods({
	'getPatients': function (endpoint) {
		// first, drop any old observations from the collection 
		Meteor.call('resetDB');
		patientEndpoint = endpoint + '/Patient';

		try {
			res = HTTP.call('GET', patientEndpoint, {
				params: {
					_count: 40 //Just get the first x patients (default I think is 100)

				},
				headers: {
					Accept: 'application/json, application/json+fhir'
				}
			}); //If there are no errors, we will end up here
			// First, see if the response got returned as data. Most servers do, but SmartHealthIT does not. If res.data is blank, we will have to convert the content (text string but should be JSON) into an object

			try {
				// use try/catch because if the content is not JSON it will fail. 
				if (!res.data) {
					res.data = JSON.parse(res.content);
				}
			} catch (e) {
				console.log(e); // if the server throws an error, we just return "no patients found"
			} // This will return a resource "bundle" which is an array of resources that match the search
			// Since we specifically searched for "Patient" all the resources are patients. 
			// Now, we only really need the Name and ID from here. Later we could pull more info. 
			// So, lets build a simple object with a list of patient names and ID's to return to the client.
			// This will need to be in the same format as our patList on the client code
			/* eg: 
   patList = [
   	{ name: 'name', id: 'id' }
   ]
   */ // First let's initialize the array- 


			patList = []; // If we get real data but no results we should return an array with a "no patients returned" message

			if (!res.data.entry) {
				patList.push({
					name: 'No patients found!',
					id: ''
				});
				return patList; // Then we just return this and thus stop here.
			} // Else, we will need to do a loop to populate this new array with things from each of the results
			//see for example: https://www.w3schools.com/js/js_loop_for.asp
			//console.dir(res.data.entry)


			for (x in res.data.entry) {
				//	console.log(res.data.entry[x].resource.name[0].given)
				var pre = res.data.entry[x].resource; // for simplicity

				try {
					// check if name exists in the result (otherwise push will error)
					patList.push({
						// the name data is unfortunately deeply nested in the FHIR object and is itself in another array. For simplicity we will just select the first given and first family names, and combine these with a space into a common "name" field
						name: pre.name[0].given + ' ' + pre.name[0].family,
						// the id is thankfully a top-level object in the resource
						id: pre.id,
						// we can also throw in sex and age in here to help set context. 
						birthDate: pre.birthDate,
						gender: pre.gender
					});
				} catch (e) {
					// Sometimes results won't have a valid name. we'll just basically ignore these errors and they simply won't make it into the patList array
					console.log('entry ' + x + ' found no valid name. Skipping.'); //console.log(e)
				}
			} // Finally, return this array to the client. 


			return patList;
		} catch (e) {
			console.log(e); // if the server throws crap, we just return:

			patList.push({
				name: 'No patients found!',
				id: ''
			});
			return patList; // and thus stop here.
		}
	},
	'getObservations': function (endpoint, patId) {
		// first, drop any old observations from the collection 
		Meteor.call('resetDB');
		ObsEndpoint = endpoint + '/Observation';

		try {
			res = HTTP.call('GET', ObsEndpoint, {
				params: {
					patient: patId //category: 'laboratory' // hard-code this to just return laboratory data
					//category: 'vital-signs' //

				},
				headers: {
					Accept: 'application/json, application/json+fhir'
				}
			}); // console.dir(res)

			try {
				// use try/catch because if the content is not JSON it will fail. 
				if (!res.data) {
					res.data = JSON.parse(res.content);
				}
			} catch (e) {
				console.log(e);
			}

			if (!res.data.entry) {
				// if no data gracefully return zero results.
				Obs.insert({});
				return true;
			} //return { results: res.data.entry.length, entries: res.data.entry } 
			// The fhir-formatted data is ugly and hard to parse through on client-side helpers.
			// For simplicity, we will go ahead and parse out the data we want for this particular patient, and pass the simpler, cleaner object to the client.
			// This is similar to how we handle the patient search above


			results = [];

			for (x in res.data.entry) {
				pre = res.data.entry[x].resource; //Use a try/catch so we don't just crash

				try {
					Obs.insert({
						codeName: pre.code.coding[0].display,
						code: pre.code.coding[0].code,
						value: pre.valueQuantity.value,
						// need to trim this to 2 decimal places, otherwise looks crappy.
						dateTime: new Date(pre.effectiveDateTime) // endpoint: endpoint,
						// patId: patId

					});
				} catch (e) {
					//console.log(e)
					// Some results will not have a single value (blood pressures) and will end up here. Since we are looking at labs we don't care. Just log and move on.
					console.log('no value for entry ' + x + ' - ' + pre.code.coding[0].display);
				}
			}

			return true;
		} catch (e) {
			console.log(e); // handle 401 (not authroized) here
		}
	}
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/Observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
	Obs: () => Obs
});
let Mongo;
module.watch(require("meteor/mongo"), {
	Mongo(v) {
		Mongo = v;
	}

}, 0);
const Obs = new Mongo.Collection('obs');

if (Meteor.isServer) {
	Meteor.publish('obs', function () {
		return Obs.find({}); // how we publish codes to the client. For now, just return everything. 
	});
	Meteor.methods({
		'resetDB': function () {
			// drop everything
			Obs.rawCollection().drop();
		}
	});
}

if (Meteor.isClient) {
	Meteor.subscribe('obs'); // Makes the collection available to the client (Templates and stuff)
}

;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.watch(require("../imports/api/server/getData.js"));
//import { Obs } from '../imports/api/Observations.js'
Meteor.startup(() => {// code to run on server at startup
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2VydmVyL2dldERhdGEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL09ic2VydmF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiT2JzIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1ldGVvciIsIm1ldGhvZHMiLCJlbmRwb2ludCIsImNhbGwiLCJwYXRpZW50RW5kcG9pbnQiLCJyZXMiLCJIVFRQIiwicGFyYW1zIiwiX2NvdW50IiwiaGVhZGVycyIsIkFjY2VwdCIsImRhdGEiLCJKU09OIiwicGFyc2UiLCJjb250ZW50IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJwYXRMaXN0IiwiZW50cnkiLCJwdXNoIiwibmFtZSIsImlkIiwieCIsInByZSIsInJlc291cmNlIiwiZ2l2ZW4iLCJmYW1pbHkiLCJiaXJ0aERhdGUiLCJnZW5kZXIiLCJwYXRJZCIsIk9ic0VuZHBvaW50IiwicGF0aWVudCIsImluc2VydCIsInJlc3VsdHMiLCJjb2RlTmFtZSIsImNvZGUiLCJjb2RpbmciLCJkaXNwbGF5IiwidmFsdWUiLCJ2YWx1ZVF1YW50aXR5IiwiZGF0ZVRpbWUiLCJEYXRlIiwiZWZmZWN0aXZlRGF0ZVRpbWUiLCJleHBvcnQiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpc1NlcnZlciIsInB1Ymxpc2giLCJmaW5kIiwicmF3Q29sbGVjdGlvbiIsImRyb3AiLCJpc0NsaWVudCIsInN1YnNjcmliZSIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsR0FBSjtBQUFRQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDSCxLQUFJSSxDQUFKLEVBQU07QUFBQ0osUUFBSUksQ0FBSjtBQUFNOztBQUFkLENBQTNDLEVBQTJELENBQTNEO0FBSVJDLE9BQU9DLE9BQVAsQ0FBZTtBQUNYLGdCQUFlLFVBQVVDLFFBQVYsRUFBb0I7QUFDL0I7QUFDQUYsU0FBT0csSUFBUCxDQUFZLFNBQVo7QUFFTkMsb0JBQWtCRixXQUFXLFVBQTdCOztBQUNBLE1BQUk7QUFDSEcsU0FBTUMsS0FBS0gsSUFBTCxDQUNKLEtBREksRUFFSkMsZUFGSSxFQUVhO0FBQ2hCRyxZQUFRO0FBQ1BDLGFBQVEsRUFERCxDQUNLOztBQURMLEtBRFE7QUFJaEJDLGFBQVM7QUFDUkMsYUFBUTtBQURBO0FBSk8sSUFGYixDQUFOLENBREcsQ0FZSDtBQUNBOztBQUVBLE9BQUc7QUFBRTtBQUNKLFFBQUksQ0FBQ0wsSUFBSU0sSUFBVCxFQUFlO0FBQ2ROLFNBQUlNLElBQUosR0FBV0MsS0FBS0MsS0FBTCxDQUFXUixJQUFJUyxPQUFmLENBQVg7QUFDQTtBQUNELElBSkQsQ0FJRSxPQUFPQyxDQUFQLEVBQVU7QUFDQ0MsWUFBUUMsR0FBUixDQUFZRixDQUFaLEVBREQsQ0FFQztBQUVaLElBdkJFLENBeUJIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztLQTlCRyxDQW1DSDs7O0FBQ0FHLGFBQVUsRUFBVixDQXBDRyxDQXNDSDs7QUFDQSxPQUFJLENBQUNiLElBQUlNLElBQUosQ0FBU1EsS0FBZCxFQUFxQjtBQUNwQkQsWUFBUUUsSUFBUixDQUFhO0FBQUVDLFdBQU0sb0JBQVI7QUFBOEJDLFNBQUk7QUFBbEMsS0FBYjtBQUNBLFdBQU9KLE9BQVAsQ0FGb0IsQ0FFTDtBQUNmLElBMUNFLENBNENIO0FBQ0E7QUFDQTs7O0FBQ0EsUUFBS0ssQ0FBTCxJQUFVbEIsSUFBSU0sSUFBSixDQUFTUSxLQUFuQixFQUEwQjtBQUV6QjtBQUNBLFFBQUlLLE1BQU1uQixJQUFJTSxJQUFKLENBQVNRLEtBQVQsQ0FBZUksQ0FBZixFQUFrQkUsUUFBNUIsQ0FIeUIsQ0FHWTs7QUFFckMsUUFBSTtBQUFFO0FBRUxQLGFBQVFFLElBQVIsQ0FBYTtBQUNaO0FBRUFDLFlBQU1HLElBQUlILElBQUosQ0FBUyxDQUFULEVBQVlLLEtBQVosR0FBb0IsR0FBcEIsR0FBMEJGLElBQUlILElBQUosQ0FBUyxDQUFULEVBQVlNLE1BSGhDO0FBSVo7QUFDQUwsVUFBSUUsSUFBSUYsRUFMSTtBQU1aO0FBQ0FNLGlCQUFXSixJQUFJSSxTQVBIO0FBUVpDLGNBQVFMLElBQUlLO0FBUkEsTUFBYjtBQVVBLEtBWkQsQ0FZRSxPQUFPZCxDQUFQLEVBQVU7QUFDWDtBQUNBQyxhQUFRQyxHQUFSLENBQVksV0FBU00sQ0FBVCxHQUFXLGlDQUF2QixFQUZXLENBR1g7QUFDQTtBQUNBLElBckVDLENBdUVIOzs7QUFDQSxVQUFPTCxPQUFQO0FBRUEsR0ExRUQsQ0EwRUUsT0FBT0gsQ0FBUCxFQUFVO0FBQ1hDLFdBQVFDLEdBQVIsQ0FBWUYsQ0FBWixFQURXLENBRVg7O0FBQ1NHLFdBQVFFLElBQVIsQ0FBYTtBQUFFQyxVQUFNLG9CQUFSO0FBQThCQyxRQUFJO0FBQWxDLElBQWI7QUFDQSxVQUFPSixPQUFQLENBSkUsQ0FJYTtBQUN4QjtBQUNELEVBdEZhO0FBd0ZYLG9CQUFtQixVQUFVaEIsUUFBVixFQUFvQjRCLEtBQXBCLEVBQTJCO0FBQzFDO0FBQ0E5QixTQUFPRyxJQUFQLENBQVksU0FBWjtBQUVONEIsZ0JBQWM3QixXQUFXLGNBQXpCOztBQUNBLE1BQUk7QUFDSEcsU0FBTUMsS0FBS0gsSUFBTCxDQUNKLEtBREksRUFFSjRCLFdBRkksRUFFUztBQUNaeEIsWUFBUTtBQUNQeUIsY0FBU0YsS0FERixDQUVQO0FBQ0E7O0FBSE8sS0FESTtBQU1ackIsYUFBUztBQUNSQyxhQUFRO0FBREE7QUFORyxJQUZULENBQU4sQ0FERyxDQWFIOztBQUNBLE9BQUk7QUFBRTtBQUNMLFFBQUksQ0FBQ0wsSUFBSU0sSUFBVCxFQUFlO0FBQ2ROLFNBQUlNLElBQUosR0FBV0MsS0FBS0MsS0FBTCxDQUFXUixJQUFJUyxPQUFmLENBQVg7QUFDQTtBQUNELElBSkQsQ0FJRSxPQUFPQyxDQUFQLEVBQVU7QUFDWEMsWUFBUUMsR0FBUixDQUFZRixDQUFaO0FBQ0E7O0FBRVEsT0FBSSxDQUFDVixJQUFJTSxJQUFKLENBQVNRLEtBQWQsRUFBcUI7QUFBRTtBQUNuQnhCLFFBQUlzQyxNQUFKLENBQVcsRUFBWDtBQUNaLFdBQU8sSUFBUDtBQUNBLElBekJFLENBMkJIO0FBQ1M7QUFDQTtBQUNBOzs7QUFDQUMsYUFBVSxFQUFWOztBQUNBLFFBQUtYLENBQUwsSUFBVWxCLElBQUlNLElBQUosQ0FBU1EsS0FBbkIsRUFBeUI7QUFDckJLLFVBQU1uQixJQUFJTSxJQUFKLENBQVNRLEtBQVQsQ0FBZUksQ0FBZixFQUFrQkUsUUFBeEIsQ0FEcUIsQ0FFckI7O0FBQ0EsUUFBSTtBQUNBOUIsU0FBSXNDLE1BQUosQ0FBVztBQUNQRSxnQkFBVVgsSUFBSVksSUFBSixDQUFTQyxNQUFULENBQWdCLENBQWhCLEVBQW1CQyxPQUR0QjtBQUVQRixZQUFNWixJQUFJWSxJQUFKLENBQVNDLE1BQVQsQ0FBZ0IsQ0FBaEIsRUFBbUJELElBRmxCO0FBR1BHLGFBQU9mLElBQUlnQixhQUFKLENBQWtCRCxLQUhsQjtBQUd5QjtBQUNoQ0UsZ0JBQVUsSUFBSUMsSUFBSixDQUFTbEIsSUFBSW1CLGlCQUFiLENBSkgsQ0FLUjtBQUNBOztBQU5RLE1BQVg7QUFRSCxLQVRELENBU0UsT0FBTzVCLENBQVAsRUFBVTtBQUNSO0FBQ0E7QUFDQUMsYUFBUUMsR0FBUixDQUFZLHdCQUFzQk0sQ0FBdEIsR0FBd0IsS0FBeEIsR0FBOEJDLElBQUlZLElBQUosQ0FBU0MsTUFBVCxDQUFnQixDQUFoQixFQUFtQkMsT0FBN0Q7QUFDSDtBQUNKOztBQUNELFVBQU8sSUFBUDtBQUNULEdBbkRELENBbURFLE9BQU92QixDQUFQLEVBQVU7QUFDWEMsV0FBUUMsR0FBUixDQUFZRixDQUFaLEVBRFcsQ0FFWDtBQUNBO0FBQ0U7QUFwSlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBbkIsT0FBT2dELE1BQVAsQ0FBYztBQUFDakQsTUFBSSxNQUFJQTtBQUFULENBQWQ7QUFBNkIsSUFBSWtELEtBQUo7QUFBVWpELE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQytDLE9BQU05QyxDQUFOLEVBQVE7QUFBQzhDLFVBQU05QyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRWhDLE1BQU1KLE1BQU0sSUFBSWtELE1BQU1DLFVBQVYsQ0FBcUIsS0FBckIsQ0FBWjs7QUFHUCxJQUFJOUMsT0FBTytDLFFBQVgsRUFBcUI7QUFDcEIvQyxRQUFPZ0QsT0FBUCxDQUFlLEtBQWYsRUFBc0IsWUFBWTtBQUNqQyxTQUFPckQsSUFBSXNELElBQUosQ0FBUyxFQUFULENBQVAsQ0FEaUMsQ0FDYjtBQUNwQixFQUZEO0FBSUFqRCxRQUFPQyxPQUFQLENBQWU7QUFDZCxhQUFXLFlBQVc7QUFBRTtBQUN2Qk4sT0FBSXVELGFBQUosR0FBb0JDLElBQXBCO0FBQ0E7QUFIYSxFQUFmO0FBS0E7O0FBRUQsSUFBSW5ELE9BQU9vRCxRQUFYLEVBQXFCO0FBQ2pCcEQsUUFBT3FELFNBQVAsQ0FBaUIsS0FBakIsRUFEaUIsQ0FDTztBQUMzQjs7QUFBQSxDOzs7Ozs7Ozs7OztBQ25CRCxJQUFJckQsTUFBSjtBQUFXSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNFLFNBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStESCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0NBQVIsQ0FBYjtBQUUxRTtBQUNBRSxPQUFPc0QsT0FBUCxDQUFlLE1BQU0sQ0FDbkI7QUFDRCxDQUZELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vU2VydmVyLXNpZGUgb25seSBtZXRob2RzIGZvciBoYW5kbGluZyBSRVNUL0ZISVIgYXBpIGNhbGxzXHJcblxyXG5pbXBvcnQgeyBPYnMgfSBmcm9tICcuLi9PYnNlcnZhdGlvbnMuanMnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcbiAgICAnZ2V0UGF0aWVudHMnOiBmdW5jdGlvbiAoZW5kcG9pbnQpIHtcclxuICAgICAgICAvLyBmaXJzdCwgZHJvcCBhbnkgb2xkIG9ic2VydmF0aW9ucyBmcm9tIHRoZSBjb2xsZWN0aW9uIFxyXG4gICAgICAgIE1ldGVvci5jYWxsKCdyZXNldERCJylcclxuXHJcblx0XHRwYXRpZW50RW5kcG9pbnQgPSBlbmRwb2ludCArICcvUGF0aWVudCdcclxuXHRcdHRyeSB7XHJcblx0XHRcdHJlcyA9IEhUVFAuY2FsbChcclxuXHRcdFx0XHRcdCdHRVQnLFxyXG5cdFx0XHRcdFx0cGF0aWVudEVuZHBvaW50LCB7XHJcblx0XHRcdFx0XHRcdHBhcmFtczoge1xyXG5cdFx0XHRcdFx0XHRcdF9jb3VudDogNDAsIC8vSnVzdCBnZXQgdGhlIGZpcnN0IHggcGF0aWVudHMgKGRlZmF1bHQgSSB0aGluayBpcyAxMDApXHJcblx0XHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRcdGhlYWRlcnM6IHtcclxuXHRcdFx0XHRcdFx0XHRBY2NlcHQ6ICdhcHBsaWNhdGlvbi9qc29uLCBhcHBsaWNhdGlvbi9qc29uK2ZoaXInXHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH0pXHJcblxyXG5cdFx0XHQvL0lmIHRoZXJlIGFyZSBubyBlcnJvcnMsIHdlIHdpbGwgZW5kIHVwIGhlcmVcclxuXHRcdFx0Ly8gRmlyc3QsIHNlZSBpZiB0aGUgcmVzcG9uc2UgZ290IHJldHVybmVkIGFzIGRhdGEuIE1vc3Qgc2VydmVycyBkbywgYnV0IFNtYXJ0SGVhbHRoSVQgZG9lcyBub3QuIElmIHJlcy5kYXRhIGlzIGJsYW5rLCB3ZSB3aWxsIGhhdmUgdG8gY29udmVydCB0aGUgY29udGVudCAodGV4dCBzdHJpbmcgYnV0IHNob3VsZCBiZSBKU09OKSBpbnRvIGFuIG9iamVjdFxyXG5cclxuXHRcdFx0dHJ5eyAvLyB1c2UgdHJ5L2NhdGNoIGJlY2F1c2UgaWYgdGhlIGNvbnRlbnQgaXMgbm90IEpTT04gaXQgd2lsbCBmYWlsLiBcclxuXHRcdFx0XHRpZiAoIXJlcy5kYXRhKSB7XHJcblx0XHRcdFx0XHRyZXMuZGF0YSA9IEpTT04ucGFyc2UocmVzLmNvbnRlbnQpXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxyXG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIHNlcnZlciB0aHJvd3MgYW4gZXJyb3IsIHdlIGp1c3QgcmV0dXJuIFwibm8gcGF0aWVudHMgZm91bmRcIlxyXG5cclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Ly8gVGhpcyB3aWxsIHJldHVybiBhIHJlc291cmNlIFwiYnVuZGxlXCIgd2hpY2ggaXMgYW4gYXJyYXkgb2YgcmVzb3VyY2VzIHRoYXQgbWF0Y2ggdGhlIHNlYXJjaFxyXG5cdFx0XHQvLyBTaW5jZSB3ZSBzcGVjaWZpY2FsbHkgc2VhcmNoZWQgZm9yIFwiUGF0aWVudFwiIGFsbCB0aGUgcmVzb3VyY2VzIGFyZSBwYXRpZW50cy4gXHJcblx0XHRcdC8vIE5vdywgd2Ugb25seSByZWFsbHkgbmVlZCB0aGUgTmFtZSBhbmQgSUQgZnJvbSBoZXJlLiBMYXRlciB3ZSBjb3VsZCBwdWxsIG1vcmUgaW5mby4gXHJcblx0XHRcdC8vIFNvLCBsZXRzIGJ1aWxkIGEgc2ltcGxlIG9iamVjdCB3aXRoIGEgbGlzdCBvZiBwYXRpZW50IG5hbWVzIGFuZCBJRCdzIHRvIHJldHVybiB0byB0aGUgY2xpZW50LlxyXG5cdFx0XHQvLyBUaGlzIHdpbGwgbmVlZCB0byBiZSBpbiB0aGUgc2FtZSBmb3JtYXQgYXMgb3VyIHBhdExpc3Qgb24gdGhlIGNsaWVudCBjb2RlXHJcblx0XHRcdC8qIGVnOiBcclxuXHRcdFx0cGF0TGlzdCA9IFtcclxuXHRcdFx0XHR7IG5hbWU6ICduYW1lJywgaWQ6ICdpZCcgfVxyXG5cdFx0XHRdXHJcblx0XHRcdCovXHJcblx0XHRcdC8vIEZpcnN0IGxldCdzIGluaXRpYWxpemUgdGhlIGFycmF5LSBcclxuXHRcdFx0cGF0TGlzdCA9IFtdXHJcblxyXG5cdFx0XHQvLyBJZiB3ZSBnZXQgcmVhbCBkYXRhIGJ1dCBubyByZXN1bHRzIHdlIHNob3VsZCByZXR1cm4gYW4gYXJyYXkgd2l0aCBhIFwibm8gcGF0aWVudHMgcmV0dXJuZWRcIiBtZXNzYWdlXHJcblx0XHRcdGlmICghcmVzLmRhdGEuZW50cnkpIHtcclxuXHRcdFx0XHRwYXRMaXN0LnB1c2goeyBuYW1lOiAnTm8gcGF0aWVudHMgZm91bmQhJywgaWQ6ICcnIH0pXHJcblx0XHRcdFx0cmV0dXJuIHBhdExpc3QgLy8gVGhlbiB3ZSBqdXN0IHJldHVybiB0aGlzIGFuZCB0aHVzIHN0b3AgaGVyZS5cclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Ly8gRWxzZSwgd2Ugd2lsbCBuZWVkIHRvIGRvIGEgbG9vcCB0byBwb3B1bGF0ZSB0aGlzIG5ldyBhcnJheSB3aXRoIHRoaW5ncyBmcm9tIGVhY2ggb2YgdGhlIHJlc3VsdHNcclxuXHRcdFx0Ly9zZWUgZm9yIGV4YW1wbGU6IGh0dHBzOi8vd3d3Lnczc2Nob29scy5jb20vanMvanNfbG9vcF9mb3IuYXNwXHJcblx0XHRcdC8vY29uc29sZS5kaXIocmVzLmRhdGEuZW50cnkpXHJcblx0XHRcdGZvciAoeCBpbiByZXMuZGF0YS5lbnRyeSkge1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdC8vXHRjb25zb2xlLmxvZyhyZXMuZGF0YS5lbnRyeVt4XS5yZXNvdXJjZS5uYW1lWzBdLmdpdmVuKVxyXG5cdFx0XHRcdHZhciBwcmUgPSByZXMuZGF0YS5lbnRyeVt4XS5yZXNvdXJjZSAvLyBmb3Igc2ltcGxpY2l0eVxyXG5cclxuXHRcdFx0XHR0cnkgeyAvLyBjaGVjayBpZiBuYW1lIGV4aXN0cyBpbiB0aGUgcmVzdWx0IChvdGhlcndpc2UgcHVzaCB3aWxsIGVycm9yKVxyXG5cclxuXHRcdFx0XHRcdHBhdExpc3QucHVzaCh7XHJcblx0XHRcdFx0XHRcdC8vIHRoZSBuYW1lIGRhdGEgaXMgdW5mb3J0dW5hdGVseSBkZWVwbHkgbmVzdGVkIGluIHRoZSBGSElSIG9iamVjdCBhbmQgaXMgaXRzZWxmIGluIGFub3RoZXIgYXJyYXkuIEZvciBzaW1wbGljaXR5IHdlIHdpbGwganVzdCBzZWxlY3QgdGhlIGZpcnN0IGdpdmVuIGFuZCBmaXJzdCBmYW1pbHkgbmFtZXMsIGFuZCBjb21iaW5lIHRoZXNlIHdpdGggYSBzcGFjZSBpbnRvIGEgY29tbW9uIFwibmFtZVwiIGZpZWxkXHJcblxyXG5cdFx0XHRcdFx0XHRuYW1lOiBwcmUubmFtZVswXS5naXZlbiArICcgJyArIHByZS5uYW1lWzBdLmZhbWlseSxcclxuXHRcdFx0XHRcdFx0Ly8gdGhlIGlkIGlzIHRoYW5rZnVsbHkgYSB0b3AtbGV2ZWwgb2JqZWN0IGluIHRoZSByZXNvdXJjZVxyXG5cdFx0XHRcdFx0XHRpZDogcHJlLmlkLFxyXG5cdFx0XHRcdFx0XHQvLyB3ZSBjYW4gYWxzbyB0aHJvdyBpbiBzZXggYW5kIGFnZSBpbiBoZXJlIHRvIGhlbHAgc2V0IGNvbnRleHQuIFxyXG5cdFx0XHRcdFx0XHRiaXJ0aERhdGU6IHByZS5iaXJ0aERhdGUsXHJcblx0XHRcdFx0XHRcdGdlbmRlcjogcHJlLmdlbmRlclxyXG5cdFx0XHRcdFx0fSlcclxuXHRcdFx0XHR9IGNhdGNoIChlKSB7XHJcblx0XHRcdFx0XHQvLyBTb21ldGltZXMgcmVzdWx0cyB3b24ndCBoYXZlIGEgdmFsaWQgbmFtZS4gd2UnbGwganVzdCBiYXNpY2FsbHkgaWdub3JlIHRoZXNlIGVycm9ycyBhbmQgdGhleSBzaW1wbHkgd29uJ3QgbWFrZSBpdCBpbnRvIHRoZSBwYXRMaXN0IGFycmF5XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZygnZW50cnkgJyt4KycgZm91bmQgbm8gdmFsaWQgbmFtZS4gU2tpcHBpbmcuJylcclxuXHRcdFx0XHRcdC8vY29uc29sZS5sb2coZSlcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0Ly8gRmluYWxseSwgcmV0dXJuIHRoaXMgYXJyYXkgdG8gdGhlIGNsaWVudC4gXHJcblx0XHRcdHJldHVybiBwYXRMaXN0XHJcblxyXG5cdFx0fSBjYXRjaCAoZSkge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhlKVxyXG5cdFx0XHQvLyBpZiB0aGUgc2VydmVyIHRocm93cyBjcmFwLCB3ZSBqdXN0IHJldHVybjpcclxuICAgICAgICAgICAgcGF0TGlzdC5wdXNoKHsgbmFtZTogJ05vIHBhdGllbnRzIGZvdW5kIScsIGlkOiAnJyB9KVxyXG4gICAgICAgICAgICByZXR1cm4gcGF0TGlzdCAvLyBhbmQgdGh1cyBzdG9wIGhlcmUuXHJcblx0XHR9XHJcblx0fSxcclxuXHJcbiAgICAnZ2V0T2JzZXJ2YXRpb25zJzogZnVuY3Rpb24gKGVuZHBvaW50LCBwYXRJZCkge1xyXG4gICAgICAgIC8vIGZpcnN0LCBkcm9wIGFueSBvbGQgb2JzZXJ2YXRpb25zIGZyb20gdGhlIGNvbGxlY3Rpb24gXHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ3Jlc2V0REInKVxyXG5cclxuXHRcdE9ic0VuZHBvaW50ID0gZW5kcG9pbnQgKyAnL09ic2VydmF0aW9uJ1xyXG5cdFx0dHJ5IHtcclxuXHRcdFx0cmVzID0gSFRUUC5jYWxsKFxyXG5cdFx0XHRcdFx0J0dFVCcsXHJcblx0XHRcdFx0XHRPYnNFbmRwb2ludCwge1xyXG5cdFx0XHRcdFx0XHRwYXJhbXM6IHtcclxuXHRcdFx0XHRcdFx0XHRwYXRpZW50OiBwYXRJZCxcclxuXHRcdFx0XHRcdFx0XHQvL2NhdGVnb3J5OiAnbGFib3JhdG9yeScgLy8gaGFyZC1jb2RlIHRoaXMgdG8ganVzdCByZXR1cm4gbGFib3JhdG9yeSBkYXRhXHJcblx0XHRcdFx0XHRcdFx0Ly9jYXRlZ29yeTogJ3ZpdGFsLXNpZ25zJyAvL1xyXG5cdFx0XHRcdFx0XHR9LFxyXG5cdFx0XHRcdFx0XHRoZWFkZXJzOiB7XHJcblx0XHRcdFx0XHRcdFx0QWNjZXB0OiAnYXBwbGljYXRpb24vanNvbiwgYXBwbGljYXRpb24vanNvbitmaGlyJ1xyXG5cdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR9KVxyXG5cdFx0XHQvLyBjb25zb2xlLmRpcihyZXMpXHJcblx0XHRcdHRyeSB7IC8vIHVzZSB0cnkvY2F0Y2ggYmVjYXVzZSBpZiB0aGUgY29udGVudCBpcyBub3QgSlNPTiBpdCB3aWxsIGZhaWwuIFxyXG5cdFx0XHRcdGlmICghcmVzLmRhdGEpIHtcclxuXHRcdFx0XHRcdHJlcy5kYXRhID0gSlNPTi5wYXJzZShyZXMuY29udGVudClcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gY2F0Y2ggKGUpIHtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhlKVxyXG5cdFx0XHR9XHJcblxyXG4gICAgICAgICAgICBpZiAoIXJlcy5kYXRhLmVudHJ5KSB7IC8vIGlmIG5vIGRhdGEgZ3JhY2VmdWxseSByZXR1cm4gemVybyByZXN1bHRzLlxyXG4gICAgICAgICAgICAgICAgT2JzLmluc2VydCh7fSlcclxuXHRcdFx0XHRyZXR1cm4gdHJ1ZVxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQvL3JldHVybiB7IHJlc3VsdHM6IHJlcy5kYXRhLmVudHJ5Lmxlbmd0aCwgZW50cmllczogcmVzLmRhdGEuZW50cnkgfSBcclxuICAgICAgICAgICAgLy8gVGhlIGZoaXItZm9ybWF0dGVkIGRhdGEgaXMgdWdseSBhbmQgaGFyZCB0byBwYXJzZSB0aHJvdWdoIG9uIGNsaWVudC1zaWRlIGhlbHBlcnMuXHJcbiAgICAgICAgICAgIC8vIEZvciBzaW1wbGljaXR5LCB3ZSB3aWxsIGdvIGFoZWFkIGFuZCBwYXJzZSBvdXQgdGhlIGRhdGEgd2Ugd2FudCBmb3IgdGhpcyBwYXJ0aWN1bGFyIHBhdGllbnQsIGFuZCBwYXNzIHRoZSBzaW1wbGVyLCBjbGVhbmVyIG9iamVjdCB0byB0aGUgY2xpZW50LlxyXG4gICAgICAgICAgICAvLyBUaGlzIGlzIHNpbWlsYXIgdG8gaG93IHdlIGhhbmRsZSB0aGUgcGF0aWVudCBzZWFyY2ggYWJvdmVcclxuICAgICAgICAgICAgcmVzdWx0cyA9IFtdXHJcbiAgICAgICAgICAgIGZvciAoeCBpbiByZXMuZGF0YS5lbnRyeSl7XHJcbiAgICAgICAgICAgICAgICBwcmUgPSByZXMuZGF0YS5lbnRyeVt4XS5yZXNvdXJjZVxyXG4gICAgICAgICAgICAgICAgLy9Vc2UgYSB0cnkvY2F0Y2ggc28gd2UgZG9uJ3QganVzdCBjcmFzaFxyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICBPYnMuaW5zZXJ0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29kZU5hbWU6IHByZS5jb2RlLmNvZGluZ1swXS5kaXNwbGF5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2RlOiBwcmUuY29kZS5jb2RpbmdbMF0uY29kZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHByZS52YWx1ZVF1YW50aXR5LnZhbHVlLCAvLyBuZWVkIHRvIHRyaW0gdGhpcyB0byAyIGRlY2ltYWwgcGxhY2VzLCBvdGhlcndpc2UgbG9va3MgY3JhcHB5LlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRlVGltZTogbmV3IERhdGUocHJlLmVmZmVjdGl2ZURhdGVUaW1lKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAvLyBlbmRwb2ludDogZW5kcG9pbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgLy8gcGF0SWQ6IHBhdElkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKGUpXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gU29tZSByZXN1bHRzIHdpbGwgbm90IGhhdmUgYSBzaW5nbGUgdmFsdWUgKGJsb29kIHByZXNzdXJlcykgYW5kIHdpbGwgZW5kIHVwIGhlcmUuIFNpbmNlIHdlIGFyZSBsb29raW5nIGF0IGxhYnMgd2UgZG9uJ3QgY2FyZS4gSnVzdCBsb2cgYW5kIG1vdmUgb24uXHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vIHZhbHVlIGZvciBlbnRyeSAnK3grJyAtICcrcHJlLmNvZGUuY29kaW5nWzBdLmRpc3BsYXkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRydWVcclxuXHRcdH0gY2F0Y2ggKGUpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coZSlcclxuXHRcdFx0Ly8gaGFuZGxlIDQwMSAobm90IGF1dGhyb2l6ZWQpIGhlcmVcclxuXHRcdH1cclxuICAgIH0sICAgXHJcbn0pXHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xyXG5cclxuZXhwb3J0IGNvbnN0IE9icyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdvYnMnKTtcclxuXHJcblxyXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XHJcblx0TWV0ZW9yLnB1Ymxpc2goJ29icycsIGZ1bmN0aW9uICgpIHtcclxuXHRcdHJldHVybiBPYnMuZmluZCh7fSkgLy8gaG93IHdlIHB1Ymxpc2ggY29kZXMgdG8gdGhlIGNsaWVudC4gRm9yIG5vdywganVzdCByZXR1cm4gZXZlcnl0aGluZy4gXHJcblx0fSlcclxuXHJcblx0TWV0ZW9yLm1ldGhvZHMoe1xyXG5cdFx0J3Jlc2V0REInOiBmdW5jdGlvbigpIHsgLy8gZHJvcCBldmVyeXRoaW5nXHJcblx0XHRcdE9icy5yYXdDb2xsZWN0aW9uKCkuZHJvcCgpXHJcblx0XHR9XHJcblx0fSlcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnb2JzJykgLy8gTWFrZXMgdGhlIGNvbGxlY3Rpb24gYXZhaWxhYmxlIHRvIHRoZSBjbGllbnQgKFRlbXBsYXRlcyBhbmQgc3R1ZmYpXHJcbn07XHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgJy4uL2ltcG9ydHMvYXBpL3NlcnZlci9nZXREYXRhLmpzJ1xuLy9pbXBvcnQgeyBPYnMgfSBmcm9tICcuLi9pbXBvcnRzL2FwaS9PYnNlcnZhdGlvbnMuanMnXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG59KTtcbiJdfQ==
