var require = meteorInstall({"imports":{"api":{"server":{"getData.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/server/getData.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Obs;
module.watch(require("../Observations.js"), {
	Obs(v) {
		Obs = v;
	}

}, 0);
Meteor.methods({
	'getPatients': function (endpoint) {
		// first, drop any old observations from the collection 
		Meteor.call('resetDB');
		patientEndpoint = endpoint + '/Patient';

		try {
			res = HTTP.call('GET', patientEndpoint, {
				params: {
					_count: 10,
					//Just get the first x patients (default I think is 100)
					_offset: 19 //Start at the 8th patient because that start on a good patient

				},
				headers: {
					Accept: 'application/json, application/json+fhir'
				}
			}); //If there are no errors, we will end up here
			// First, see if the response got returned as data. Most servers do, but SmartHealthIT does not. If res.data is blank, we will have to convert the content (text string but should be JSON) into an object

			try {
				// use try/catch because if the content is not JSON it will fail. 
				if (!res.data) {
					res.data = JSON.parse(res.content);
				}
			} catch (e) {
				console.log(e); // if the server throws an error, we just return "no patients found"
			} // This will return a resource "bundle" which is an array of resources that match the search
			// Since we specifically searched for "Patient" all the resources are patients. 
			// Now, we only really need the Name and ID from here. Later we could pull more info. 
			// So, lets build a simple object with a list of patient names and ID's to return to the client.
			// This will need to be in the same format as our patList on the client code
			/* eg: 
   patList = [
   	{ name: 'name', id: 'id' }
   ]
   */ // First let's initialize the array- 


			patList = []; // If we get real data but no results we should return an array with a "no patients returned" message

			if (!res.data.entry) {
				patList.push({
					name: 'No patients found!',
					id: ''
				});
				return patList; // Then we just return this and thus stop here.
			} // Else, we will need to do a loop to populate this new array with things from each of the results
			//see for example: https://www.w3schools.com/js/js_loop_for.asp
			//console.dir(res.data.entry)


			for (x in res.data.entry) {
				//	console.log(res.data.entry[x].resource.name[0].given)
				var pre = res.data.entry[x].resource; // for simplicity

				try {
					// check if name exists in the result (otherwise push will error)
					patList.push({
						// the name data is unfortunately deeply nested in the FHIR object and is itself in another array. For simplicity we will just select the first given and first family names, and combine these with a space into a common "name" field
						name: pre.name[0].given + ' ' + pre.name[0].family,
						// the id is thankfully a top-level object in the resource
						id: pre.id,
						// we can also throw in sex and age in here to help set context. 
						birthDate: pre.birthDate,
						gender: pre.gender
					});
				} catch (e) {
					// Sometimes results won't have a valid name. we'll just basically ignore these errors and they simply won't make it into the patList array
					console.log('entry ' + x + ' found no valid name. Skipping.'); //console.log(e)
				}
			} // Finally, return this array to the client. 


			return patList;
		} catch (e) {
			//console.log(e)
			// if the server throws crap, we just return:
			patList.push({
				name: 'No patients found!',
				id: ''
			});
			return patList; // and thus stop here.
		}
	},
	'getObservations': function (endpoint, patId) {
		// first, drop any old observations from the collection 
		Meteor.call('resetDB');
		ObsEndpoint = endpoint + '/Observation';

		try {
			res = HTTP.call('GET', ObsEndpoint, {
				params: {
					patient: patId,
					//category: 'laboratory' // hard-code this to just return laboratory data
					//category: 'vital-signs' //
					_count: 1000 // we try

				},
				headers: {
					Accept: 'application/json, application/json+fhir'
				}
			}); // console.dir(res)

			try {
				// use try/catch because if the content is not JSON it will fail. 
				if (!res.data) {
					res.data = JSON.parse(res.content);
				}
			} catch (e) {
				console.log(e);
			}

			results = [];

			if (!res.data.entry) {
				// if no data gracefully return zero results.
				results.push({});
				return results;
			} // Max results are 100 per search- we want them all, so figure out if there are next pages. If so, do the call and add the results to the pile. 
			// console.log(res.data.link)


			while (res.data.link) //return { results: res.data.entry.length, entries: res.data.entry } 
			// The fhir-formatted data is ugly and hard to parse through on client-side helpers.
			// For simplicity, we will go ahead and parse out the data we want for this particular patient, and pass the simpler, cleaner object to the client.
			// This is similar to how we handle the patient search above
			//console.dir(res.data)
			return res.data.entry; /*
                            for (x in res.data.entry){
                              pre = res.data.entry[x].resource
                              //Use a try/catch so we don't just crash
                              console.log(pre)
                              try {
                                  if(pre.valueQuantity.value){ // if there is an individual value, we will use that
                                      results.push({
                                          codeName: pre.code.coding[0].display,
                                          code: pre.code.coding[0].code,
                                          value: pre.valueQuantity.value, // need to trim this to 2 decimal places, otherwise looks crappy.
                                          unit: pre.valueQuantity.unit,
                                          dateTime: new Date(pre.effectiveDateTime),
                                           // endpoint: endpoint,
                                         // patId: patId
                                      })
                                  } else {
                                      // if there is not an individual value (like a BP) we need to do more logic...
                                      // for now just do nothing
                                      null
                                  }
                              } catch (e) {
                                  console.log(e)
                                  // Some results will not have a single value (blood pressures) and will end up here. Since we are looking at labs we don't care. Just log and move on.
                                  //console.log('no value for entry '+x+' - '+pre.code.coding[0].display)
                              }
                            }
                          return results
                            */
		} catch (e) {
			console.log(e); // handle 401 (not authroized) here
		}
	}
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"Observations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/Observations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
    Obs: () => Obs
});
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 0);
const Obs = new Mongo.Collection(null);
// change this to a local collection only (no DB, but still get Mongo functionality!)
Meteor.methods({
    'resetDB': function () {
        // drop everything
        Obs.remove({});
    }
}); /*
    if (Meteor.isServer) {
    	Meteor.publish('obs', function () {
    		return Obs.find({}) // how we publish codes to the client. For now, just return everything. 
    	})
    
    
    if (Meteor.isClient) {
        Meteor.subscribe('obs') // Makes the collection available to the client (Templates and stuff)
    };
    
    
    */
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
module.watch(require("../imports/api/server/getData.js"));
//import { Obs } from '../imports/api/Observations.js'
Meteor.startup(() => {// code to run on server at startup
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc2VydmVyL2dldERhdGEuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL09ic2VydmF0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiT2JzIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1ldGVvciIsIm1ldGhvZHMiLCJlbmRwb2ludCIsImNhbGwiLCJwYXRpZW50RW5kcG9pbnQiLCJyZXMiLCJIVFRQIiwicGFyYW1zIiwiX2NvdW50IiwiX29mZnNldCIsImhlYWRlcnMiLCJBY2NlcHQiLCJkYXRhIiwiSlNPTiIsInBhcnNlIiwiY29udGVudCIsImUiLCJjb25zb2xlIiwibG9nIiwicGF0TGlzdCIsImVudHJ5IiwicHVzaCIsIm5hbWUiLCJpZCIsIngiLCJwcmUiLCJyZXNvdXJjZSIsImdpdmVuIiwiZmFtaWx5IiwiYmlydGhEYXRlIiwiZ2VuZGVyIiwicGF0SWQiLCJPYnNFbmRwb2ludCIsInBhdGllbnQiLCJyZXN1bHRzIiwibGluayIsImV4cG9ydCIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsInJlbW92ZSIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsR0FBSjtBQUFRQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDSCxLQUFJSSxDQUFKLEVBQU07QUFBQ0osUUFBSUksQ0FBSjtBQUFNOztBQUFkLENBQTNDLEVBQTJELENBQTNEO0FBSVJDLE9BQU9DLE9BQVAsQ0FBZTtBQUNYLGdCQUFlLFVBQVVDLFFBQVYsRUFBb0I7QUFDL0I7QUFDQUYsU0FBT0csSUFBUCxDQUFZLFNBQVo7QUFFTkMsb0JBQWtCRixXQUFXLFVBQTdCOztBQUNBLE1BQUk7QUFDSEcsU0FBTUMsS0FBS0gsSUFBTCxDQUNKLEtBREksRUFFSkMsZUFGSSxFQUVhO0FBQ2hCRyxZQUFRO0FBQ2NDLGFBQVEsRUFEdEI7QUFDMEI7QUFDWkMsY0FBUyxFQUZ2QixDQUUwQjs7QUFGMUIsS0FEUTtBQUtoQkMsYUFBUztBQUNSQyxhQUFRO0FBREE7QUFMTyxJQUZiLENBQU4sQ0FERyxDQWFIO0FBQ0E7O0FBRUEsT0FBRztBQUFFO0FBQ0osUUFBSSxDQUFDTixJQUFJTyxJQUFULEVBQWU7QUFDZFAsU0FBSU8sSUFBSixHQUFXQyxLQUFLQyxLQUFMLENBQVdULElBQUlVLE9BQWYsQ0FBWDtBQUNBO0FBQ0QsSUFKRCxDQUlFLE9BQU9DLENBQVAsRUFBVTtBQUNDQyxZQUFRQyxHQUFSLENBQVlGLENBQVosRUFERCxDQUVDO0FBRVosSUF4QkUsQ0EwQkg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0tBL0JHLENBb0NIOzs7QUFDQUcsYUFBVSxFQUFWLENBckNHLENBdUNIOztBQUNBLE9BQUksQ0FBQ2QsSUFBSU8sSUFBSixDQUFTUSxLQUFkLEVBQXFCO0FBQ3BCRCxZQUFRRSxJQUFSLENBQWE7QUFBRUMsV0FBTSxvQkFBUjtBQUE4QkMsU0FBSTtBQUFsQyxLQUFiO0FBQ0EsV0FBT0osT0FBUCxDQUZvQixDQUVMO0FBQ2YsSUEzQ0UsQ0E2Q0g7QUFDQTtBQUNBOzs7QUFDQSxRQUFLSyxDQUFMLElBQVVuQixJQUFJTyxJQUFKLENBQVNRLEtBQW5CLEVBQTBCO0FBRXpCO0FBQ0EsUUFBSUssTUFBTXBCLElBQUlPLElBQUosQ0FBU1EsS0FBVCxDQUFlSSxDQUFmLEVBQWtCRSxRQUE1QixDQUh5QixDQUdZOztBQUVyQyxRQUFJO0FBQUU7QUFFTFAsYUFBUUUsSUFBUixDQUFhO0FBQ1o7QUFFQUMsWUFBTUcsSUFBSUgsSUFBSixDQUFTLENBQVQsRUFBWUssS0FBWixHQUFvQixHQUFwQixHQUEwQkYsSUFBSUgsSUFBSixDQUFTLENBQVQsRUFBWU0sTUFIaEM7QUFJWjtBQUNBTCxVQUFJRSxJQUFJRixFQUxJO0FBTVo7QUFDQU0saUJBQVdKLElBQUlJLFNBUEg7QUFRWkMsY0FBUUwsSUFBSUs7QUFSQSxNQUFiO0FBVUEsS0FaRCxDQVlFLE9BQU9kLENBQVAsRUFBVTtBQUNYO0FBQ0FDLGFBQVFDLEdBQVIsQ0FBWSxXQUFTTSxDQUFULEdBQVcsaUNBQXZCLEVBRlcsQ0FHWDtBQUNBO0FBQ0EsSUF0RUMsQ0F3RUg7OztBQUNBLFVBQU9MLE9BQVA7QUFFQSxHQTNFRCxDQTJFRSxPQUFPSCxDQUFQLEVBQVU7QUFDWDtBQUNBO0FBQ1NHLFdBQVFFLElBQVIsQ0FBYTtBQUFFQyxVQUFNLG9CQUFSO0FBQThCQyxRQUFJO0FBQWxDLElBQWI7QUFDQSxVQUFPSixPQUFQLENBSkUsQ0FJYTtBQUN4QjtBQUNELEVBdkZhO0FBeUZYLG9CQUFtQixVQUFVakIsUUFBVixFQUFvQjZCLEtBQXBCLEVBQTJCO0FBQzFDO0FBQ0EvQixTQUFPRyxJQUFQLENBQVksU0FBWjtBQUVONkIsZ0JBQWM5QixXQUFXLGNBQXpCOztBQUNBLE1BQUk7QUFDSEcsU0FBTUMsS0FBS0gsSUFBTCxDQUNKLEtBREksRUFFSjZCLFdBRkksRUFFUztBQUNaekIsWUFBUTtBQUNQMEIsY0FBU0YsS0FERjtBQUVQO0FBQ0E7QUFDcUJ2QixhQUFRLElBSnRCLENBSTJCOztBQUozQixLQURJO0FBT1pFLGFBQVM7QUFDUkMsYUFBUTtBQURBO0FBUEcsSUFGVCxDQUFOLENBREcsQ0FjSDs7QUFDQSxPQUFJO0FBQUU7QUFDTCxRQUFJLENBQUNOLElBQUlPLElBQVQsRUFBZTtBQUNkUCxTQUFJTyxJQUFKLEdBQVdDLEtBQUtDLEtBQUwsQ0FBV1QsSUFBSVUsT0FBZixDQUFYO0FBQ0E7QUFDRCxJQUpELENBSUUsT0FBT0MsQ0FBUCxFQUFVO0FBQ1hDLFlBQVFDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNBOztBQUVRa0IsYUFBVSxFQUFWOztBQUVBLE9BQUksQ0FBQzdCLElBQUlPLElBQUosQ0FBU1EsS0FBZCxFQUFxQjtBQUFFO0FBQ25CYyxZQUFRYixJQUFSLENBQWEsRUFBYjtBQUNaLFdBQU9hLE9BQVA7QUFDQSxJQTVCRSxDQThCTTtBQUNEOzs7QUFFQyxVQUFPN0IsSUFBSU8sSUFBSixDQUFTdUIsSUFBaEIsRUFHVDtBQUNTO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBTzlCLElBQUlPLElBQUosQ0FBU1EsS0FBaEIsQ0F6Q04sQ0EyQ007Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUNULEdBNUVELENBNEVFLE9BQU9KLENBQVAsRUFBVTtBQUNYQyxXQUFRQyxHQUFSLENBQVlGLENBQVosRUFEVyxDQUVYO0FBQ0E7QUFDRTtBQTlLVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkFwQixPQUFPd0MsTUFBUCxDQUFjO0FBQUN6QyxTQUFJLE1BQUlBO0FBQVQsQ0FBZDtBQUE2QixJQUFJMEMsS0FBSjtBQUFVekMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDdUMsVUFBTXRDLENBQU4sRUFBUTtBQUFDc0MsZ0JBQU10QyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRWhDLE1BQU1KLE1BQU0sSUFBSTBDLE1BQU1DLFVBQVYsQ0FBcUIsSUFBckIsQ0FBWjtBQUF3QztBQUUvQ3RDLE9BQU9DLE9BQVAsQ0FBZTtBQUNYLGVBQVcsWUFBWTtBQUFFO0FBQ3JCTixZQUFJNEMsTUFBSixDQUFXLEVBQVg7QUFDSDtBQUhVLENBQWYsRSxDQU1BOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1ZBLElBQUl2QyxNQUFKO0FBQVdKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0UsU0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0RILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQ0FBUixDQUFiO0FBRTFFO0FBQ0FFLE9BQU93QyxPQUFQLENBQWUsTUFBTSxDQUNuQjtBQUNELENBRkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy9TZXJ2ZXItc2lkZSBvbmx5IG1ldGhvZHMgZm9yIGhhbmRsaW5nIFJFU1QvRkhJUiBhcGkgY2FsbHNcclxuXHJcbmltcG9ydCB7IE9icyB9IGZyb20gJy4uL09ic2VydmF0aW9ucy5qcydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdnZXRQYXRpZW50cyc6IGZ1bmN0aW9uIChlbmRwb2ludCkge1xyXG4gICAgICAgIC8vIGZpcnN0LCBkcm9wIGFueSBvbGQgb2JzZXJ2YXRpb25zIGZyb20gdGhlIGNvbGxlY3Rpb24gXHJcbiAgICAgICAgTWV0ZW9yLmNhbGwoJ3Jlc2V0REInKVxyXG5cclxuXHRcdHBhdGllbnRFbmRwb2ludCA9IGVuZHBvaW50ICsgJy9QYXRpZW50J1xyXG5cdFx0dHJ5IHtcclxuXHRcdFx0cmVzID0gSFRUUC5jYWxsKFxyXG5cdFx0XHRcdFx0J0dFVCcsXHJcblx0XHRcdFx0XHRwYXRpZW50RW5kcG9pbnQsIHtcclxuXHRcdFx0XHRcdFx0cGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfY291bnQ6IDEwLCAvL0p1c3QgZ2V0IHRoZSBmaXJzdCB4IHBhdGllbnRzIChkZWZhdWx0IEkgdGhpbmsgaXMgMTAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX29mZnNldDogMTkgLy9TdGFydCBhdCB0aGUgOHRoIHBhdGllbnQgYmVjYXVzZSB0aGF0IHN0YXJ0IG9uIGEgZ29vZCBwYXRpZW50XHJcblx0XHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRcdGhlYWRlcnM6IHtcclxuXHRcdFx0XHRcdFx0XHRBY2NlcHQ6ICdhcHBsaWNhdGlvbi9qc29uLCBhcHBsaWNhdGlvbi9qc29uK2ZoaXInXHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH0pXHJcblxyXG5cdFx0XHQvL0lmIHRoZXJlIGFyZSBubyBlcnJvcnMsIHdlIHdpbGwgZW5kIHVwIGhlcmVcclxuXHRcdFx0Ly8gRmlyc3QsIHNlZSBpZiB0aGUgcmVzcG9uc2UgZ290IHJldHVybmVkIGFzIGRhdGEuIE1vc3Qgc2VydmVycyBkbywgYnV0IFNtYXJ0SGVhbHRoSVQgZG9lcyBub3QuIElmIHJlcy5kYXRhIGlzIGJsYW5rLCB3ZSB3aWxsIGhhdmUgdG8gY29udmVydCB0aGUgY29udGVudCAodGV4dCBzdHJpbmcgYnV0IHNob3VsZCBiZSBKU09OKSBpbnRvIGFuIG9iamVjdFxyXG5cclxuXHRcdFx0dHJ5eyAvLyB1c2UgdHJ5L2NhdGNoIGJlY2F1c2UgaWYgdGhlIGNvbnRlbnQgaXMgbm90IEpTT04gaXQgd2lsbCBmYWlsLiBcclxuXHRcdFx0XHRpZiAoIXJlcy5kYXRhKSB7XHJcblx0XHRcdFx0XHRyZXMuZGF0YSA9IEpTT04ucGFyc2UocmVzLmNvbnRlbnQpXHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxyXG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIHNlcnZlciB0aHJvd3MgYW4gZXJyb3IsIHdlIGp1c3QgcmV0dXJuIFwibm8gcGF0aWVudHMgZm91bmRcIlxyXG5cclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Ly8gVGhpcyB3aWxsIHJldHVybiBhIHJlc291cmNlIFwiYnVuZGxlXCIgd2hpY2ggaXMgYW4gYXJyYXkgb2YgcmVzb3VyY2VzIHRoYXQgbWF0Y2ggdGhlIHNlYXJjaFxyXG5cdFx0XHQvLyBTaW5jZSB3ZSBzcGVjaWZpY2FsbHkgc2VhcmNoZWQgZm9yIFwiUGF0aWVudFwiIGFsbCB0aGUgcmVzb3VyY2VzIGFyZSBwYXRpZW50cy4gXHJcblx0XHRcdC8vIE5vdywgd2Ugb25seSByZWFsbHkgbmVlZCB0aGUgTmFtZSBhbmQgSUQgZnJvbSBoZXJlLiBMYXRlciB3ZSBjb3VsZCBwdWxsIG1vcmUgaW5mby4gXHJcblx0XHRcdC8vIFNvLCBsZXRzIGJ1aWxkIGEgc2ltcGxlIG9iamVjdCB3aXRoIGEgbGlzdCBvZiBwYXRpZW50IG5hbWVzIGFuZCBJRCdzIHRvIHJldHVybiB0byB0aGUgY2xpZW50LlxyXG5cdFx0XHQvLyBUaGlzIHdpbGwgbmVlZCB0byBiZSBpbiB0aGUgc2FtZSBmb3JtYXQgYXMgb3VyIHBhdExpc3Qgb24gdGhlIGNsaWVudCBjb2RlXHJcblx0XHRcdC8qIGVnOiBcclxuXHRcdFx0cGF0TGlzdCA9IFtcclxuXHRcdFx0XHR7IG5hbWU6ICduYW1lJywgaWQ6ICdpZCcgfVxyXG5cdFx0XHRdXHJcblx0XHRcdCovXHJcblx0XHRcdC8vIEZpcnN0IGxldCdzIGluaXRpYWxpemUgdGhlIGFycmF5LSBcclxuXHRcdFx0cGF0TGlzdCA9IFtdXHJcblxyXG5cdFx0XHQvLyBJZiB3ZSBnZXQgcmVhbCBkYXRhIGJ1dCBubyByZXN1bHRzIHdlIHNob3VsZCByZXR1cm4gYW4gYXJyYXkgd2l0aCBhIFwibm8gcGF0aWVudHMgcmV0dXJuZWRcIiBtZXNzYWdlXHJcblx0XHRcdGlmICghcmVzLmRhdGEuZW50cnkpIHtcclxuXHRcdFx0XHRwYXRMaXN0LnB1c2goeyBuYW1lOiAnTm8gcGF0aWVudHMgZm91bmQhJywgaWQ6ICcnIH0pXHJcblx0XHRcdFx0cmV0dXJuIHBhdExpc3QgLy8gVGhlbiB3ZSBqdXN0IHJldHVybiB0aGlzIGFuZCB0aHVzIHN0b3AgaGVyZS5cclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Ly8gRWxzZSwgd2Ugd2lsbCBuZWVkIHRvIGRvIGEgbG9vcCB0byBwb3B1bGF0ZSB0aGlzIG5ldyBhcnJheSB3aXRoIHRoaW5ncyBmcm9tIGVhY2ggb2YgdGhlIHJlc3VsdHNcclxuXHRcdFx0Ly9zZWUgZm9yIGV4YW1wbGU6IGh0dHBzOi8vd3d3Lnczc2Nob29scy5jb20vanMvanNfbG9vcF9mb3IuYXNwXHJcblx0XHRcdC8vY29uc29sZS5kaXIocmVzLmRhdGEuZW50cnkpXHJcblx0XHRcdGZvciAoeCBpbiByZXMuZGF0YS5lbnRyeSkge1xyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdC8vXHRjb25zb2xlLmxvZyhyZXMuZGF0YS5lbnRyeVt4XS5yZXNvdXJjZS5uYW1lWzBdLmdpdmVuKVxyXG5cdFx0XHRcdHZhciBwcmUgPSByZXMuZGF0YS5lbnRyeVt4XS5yZXNvdXJjZSAvLyBmb3Igc2ltcGxpY2l0eVxyXG5cclxuXHRcdFx0XHR0cnkgeyAvLyBjaGVjayBpZiBuYW1lIGV4aXN0cyBpbiB0aGUgcmVzdWx0IChvdGhlcndpc2UgcHVzaCB3aWxsIGVycm9yKVxyXG5cclxuXHRcdFx0XHRcdHBhdExpc3QucHVzaCh7XHJcblx0XHRcdFx0XHRcdC8vIHRoZSBuYW1lIGRhdGEgaXMgdW5mb3J0dW5hdGVseSBkZWVwbHkgbmVzdGVkIGluIHRoZSBGSElSIG9iamVjdCBhbmQgaXMgaXRzZWxmIGluIGFub3RoZXIgYXJyYXkuIEZvciBzaW1wbGljaXR5IHdlIHdpbGwganVzdCBzZWxlY3QgdGhlIGZpcnN0IGdpdmVuIGFuZCBmaXJzdCBmYW1pbHkgbmFtZXMsIGFuZCBjb21iaW5lIHRoZXNlIHdpdGggYSBzcGFjZSBpbnRvIGEgY29tbW9uIFwibmFtZVwiIGZpZWxkXHJcblxyXG5cdFx0XHRcdFx0XHRuYW1lOiBwcmUubmFtZVswXS5naXZlbiArICcgJyArIHByZS5uYW1lWzBdLmZhbWlseSxcclxuXHRcdFx0XHRcdFx0Ly8gdGhlIGlkIGlzIHRoYW5rZnVsbHkgYSB0b3AtbGV2ZWwgb2JqZWN0IGluIHRoZSByZXNvdXJjZVxyXG5cdFx0XHRcdFx0XHRpZDogcHJlLmlkLFxyXG5cdFx0XHRcdFx0XHQvLyB3ZSBjYW4gYWxzbyB0aHJvdyBpbiBzZXggYW5kIGFnZSBpbiBoZXJlIHRvIGhlbHAgc2V0IGNvbnRleHQuIFxyXG5cdFx0XHRcdFx0XHRiaXJ0aERhdGU6IHByZS5iaXJ0aERhdGUsXHJcblx0XHRcdFx0XHRcdGdlbmRlcjogcHJlLmdlbmRlclxyXG5cdFx0XHRcdFx0fSlcclxuXHRcdFx0XHR9IGNhdGNoIChlKSB7XHJcblx0XHRcdFx0XHQvLyBTb21ldGltZXMgcmVzdWx0cyB3b24ndCBoYXZlIGEgdmFsaWQgbmFtZS4gd2UnbGwganVzdCBiYXNpY2FsbHkgaWdub3JlIHRoZXNlIGVycm9ycyBhbmQgdGhleSBzaW1wbHkgd29uJ3QgbWFrZSBpdCBpbnRvIHRoZSBwYXRMaXN0IGFycmF5XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZygnZW50cnkgJyt4KycgZm91bmQgbm8gdmFsaWQgbmFtZS4gU2tpcHBpbmcuJylcclxuXHRcdFx0XHRcdC8vY29uc29sZS5sb2coZSlcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cclxuXHRcdFx0Ly8gRmluYWxseSwgcmV0dXJuIHRoaXMgYXJyYXkgdG8gdGhlIGNsaWVudC4gXHJcblx0XHRcdHJldHVybiBwYXRMaXN0XHJcblxyXG5cdFx0fSBjYXRjaCAoZSkge1xyXG5cdFx0XHQvL2NvbnNvbGUubG9nKGUpXHJcblx0XHRcdC8vIGlmIHRoZSBzZXJ2ZXIgdGhyb3dzIGNyYXAsIHdlIGp1c3QgcmV0dXJuOlxyXG4gICAgICAgICAgICBwYXRMaXN0LnB1c2goeyBuYW1lOiAnTm8gcGF0aWVudHMgZm91bmQhJywgaWQ6ICcnIH0pXHJcbiAgICAgICAgICAgIHJldHVybiBwYXRMaXN0IC8vIGFuZCB0aHVzIHN0b3AgaGVyZS5cclxuXHRcdH1cclxuXHR9LFxyXG5cclxuICAgICdnZXRPYnNlcnZhdGlvbnMnOiBmdW5jdGlvbiAoZW5kcG9pbnQsIHBhdElkKSB7XHJcbiAgICAgICAgLy8gZmlyc3QsIGRyb3AgYW55IG9sZCBvYnNlcnZhdGlvbnMgZnJvbSB0aGUgY29sbGVjdGlvbiBcclxuICAgICAgICBNZXRlb3IuY2FsbCgncmVzZXREQicpXHJcblxyXG5cdFx0T2JzRW5kcG9pbnQgPSBlbmRwb2ludCArICcvT2JzZXJ2YXRpb24nXHJcblx0XHR0cnkge1xyXG5cdFx0XHRyZXMgPSBIVFRQLmNhbGwoXHJcblx0XHRcdFx0XHQnR0VUJyxcclxuXHRcdFx0XHRcdE9ic0VuZHBvaW50LCB7XHJcblx0XHRcdFx0XHRcdHBhcmFtczoge1xyXG5cdFx0XHRcdFx0XHRcdHBhdGllbnQ6IHBhdElkLFxyXG5cdFx0XHRcdFx0XHRcdC8vY2F0ZWdvcnk6ICdsYWJvcmF0b3J5JyAvLyBoYXJkLWNvZGUgdGhpcyB0byBqdXN0IHJldHVybiBsYWJvcmF0b3J5IGRhdGFcclxuXHRcdFx0XHRcdFx0XHQvL2NhdGVnb3J5OiAndml0YWwtc2lnbnMnIC8vXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfY291bnQ6IDEwMDAgLy8gd2UgdHJ5XHJcblx0XHRcdFx0XHRcdH0sXHJcblx0XHRcdFx0XHRcdGhlYWRlcnM6IHtcclxuXHRcdFx0XHRcdFx0XHRBY2NlcHQ6ICdhcHBsaWNhdGlvbi9qc29uLCBhcHBsaWNhdGlvbi9qc29uK2ZoaXInXHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH0pXHJcblx0XHRcdC8vIGNvbnNvbGUuZGlyKHJlcylcclxuXHRcdFx0dHJ5IHsgLy8gdXNlIHRyeS9jYXRjaCBiZWNhdXNlIGlmIHRoZSBjb250ZW50IGlzIG5vdCBKU09OIGl0IHdpbGwgZmFpbC4gXHJcblx0XHRcdFx0aWYgKCFyZXMuZGF0YSkge1xyXG5cdFx0XHRcdFx0cmVzLmRhdGEgPSBKU09OLnBhcnNlKHJlcy5jb250ZW50KVxyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSBjYXRjaCAoZSkge1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKGUpXHJcblx0XHRcdH1cclxuXHJcbiAgICAgICAgICAgIHJlc3VsdHMgPSBbXVxyXG5cclxuICAgICAgICAgICAgaWYgKCFyZXMuZGF0YS5lbnRyeSkgeyAvLyBpZiBubyBkYXRhIGdyYWNlZnVsbHkgcmV0dXJuIHplcm8gcmVzdWx0cy5cclxuICAgICAgICAgICAgICAgIHJlc3VsdHMucHVzaCh7fSlcclxuXHRcdFx0XHRyZXR1cm4gcmVzdWx0c1xyXG5cdFx0XHR9XHJcblxyXG4gICAgICAgICAgICAvLyBNYXggcmVzdWx0cyBhcmUgMTAwIHBlciBzZWFyY2gtIHdlIHdhbnQgdGhlbSBhbGwsIHNvIGZpZ3VyZSBvdXQgaWYgdGhlcmUgYXJlIG5leHQgcGFnZXMuIElmIHNvLCBkbyB0aGUgY2FsbCBhbmQgYWRkIHRoZSByZXN1bHRzIHRvIHRoZSBwaWxlLiBcclxuICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXMuZGF0YS5saW5rKVxyXG5cclxuICAgICAgICAgICAgd2hpbGUgKHJlcy5kYXRhLmxpbmspXHJcblxyXG5cclxuXHRcdFx0Ly9yZXR1cm4geyByZXN1bHRzOiByZXMuZGF0YS5lbnRyeS5sZW5ndGgsIGVudHJpZXM6IHJlcy5kYXRhLmVudHJ5IH0gXHJcbiAgICAgICAgICAgIC8vIFRoZSBmaGlyLWZvcm1hdHRlZCBkYXRhIGlzIHVnbHkgYW5kIGhhcmQgdG8gcGFyc2UgdGhyb3VnaCBvbiBjbGllbnQtc2lkZSBoZWxwZXJzLlxyXG4gICAgICAgICAgICAvLyBGb3Igc2ltcGxpY2l0eSwgd2Ugd2lsbCBnbyBhaGVhZCBhbmQgcGFyc2Ugb3V0IHRoZSBkYXRhIHdlIHdhbnQgZm9yIHRoaXMgcGFydGljdWxhciBwYXRpZW50LCBhbmQgcGFzcyB0aGUgc2ltcGxlciwgY2xlYW5lciBvYmplY3QgdG8gdGhlIGNsaWVudC5cclxuICAgICAgICAgICAgLy8gVGhpcyBpcyBzaW1pbGFyIHRvIGhvdyB3ZSBoYW5kbGUgdGhlIHBhdGllbnQgc2VhcmNoIGFib3ZlXHJcbiAgICAgICAgICAgIC8vY29uc29sZS5kaXIocmVzLmRhdGEpXHJcbiAgICAgICAgICAgIHJldHVybiByZXMuZGF0YS5lbnRyeVxyXG5cclxuICAgICAgICAgICAgLypcclxuXHJcbiAgICAgICAgICAgIGZvciAoeCBpbiByZXMuZGF0YS5lbnRyeSl7XHJcbiAgICAgICAgICAgICAgICBwcmUgPSByZXMuZGF0YS5lbnRyeVt4XS5yZXNvdXJjZVxyXG4gICAgICAgICAgICAgICAgLy9Vc2UgYSB0cnkvY2F0Y2ggc28gd2UgZG9uJ3QganVzdCBjcmFzaFxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cocHJlKVxyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICBpZihwcmUudmFsdWVRdWFudGl0eS52YWx1ZSl7IC8vIGlmIHRoZXJlIGlzIGFuIGluZGl2aWR1YWwgdmFsdWUsIHdlIHdpbGwgdXNlIHRoYXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGVOYW1lOiBwcmUuY29kZS5jb2RpbmdbMF0uZGlzcGxheSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvZGU6IHByZS5jb2RlLmNvZGluZ1swXS5jb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHByZS52YWx1ZVF1YW50aXR5LnZhbHVlLCAvLyBuZWVkIHRvIHRyaW0gdGhpcyB0byAyIGRlY2ltYWwgcGxhY2VzLCBvdGhlcndpc2UgbG9va3MgY3JhcHB5LlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5pdDogcHJlLnZhbHVlUXVhbnRpdHkudW5pdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGVUaW1lOiBuZXcgRGF0ZShwcmUuZWZmZWN0aXZlRGF0ZVRpbWUpLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZW5kcG9pbnQ6IGVuZHBvaW50LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBwYXRJZDogcGF0SWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGVyZSBpcyBub3QgYW4gaW5kaXZpZHVhbCB2YWx1ZSAobGlrZSBhIEJQKSB3ZSBuZWVkIHRvIGRvIG1vcmUgbG9naWMuLi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZm9yIG5vdyBqdXN0IGRvIG5vdGhpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIFNvbWUgcmVzdWx0cyB3aWxsIG5vdCBoYXZlIGEgc2luZ2xlIHZhbHVlIChibG9vZCBwcmVzc3VyZXMpIGFuZCB3aWxsIGVuZCB1cCBoZXJlLiBTaW5jZSB3ZSBhcmUgbG9va2luZyBhdCBsYWJzIHdlIGRvbid0IGNhcmUuIEp1c3QgbG9nIGFuZCBtb3ZlIG9uLlxyXG4gICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coJ25vIHZhbHVlIGZvciBlbnRyeSAnK3grJyAtICcrcHJlLmNvZGUuY29kaW5nWzBdLmRpc3BsYXkpXHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHRzXHJcblxyXG4gICAgICAgICAgICAqL1xyXG5cdFx0fSBjYXRjaCAoZSkge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhlKVxyXG5cdFx0XHQvLyBoYW5kbGUgNDAxIChub3QgYXV0aHJvaXplZCkgaGVyZVxyXG5cdFx0fVxyXG4gICAgfSwgICBcclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcblxyXG5leHBvcnQgY29uc3QgT2JzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24obnVsbCk7IC8vIGNoYW5nZSB0aGlzIHRvIGEgbG9jYWwgY29sbGVjdGlvbiBvbmx5IChubyBEQiwgYnV0IHN0aWxsIGdldCBNb25nbyBmdW5jdGlvbmFsaXR5ISlcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdyZXNldERCJzogZnVuY3Rpb24gKCkgeyAvLyBkcm9wIGV2ZXJ5dGhpbmdcclxuICAgICAgICBPYnMucmVtb3ZlKHt9KVxyXG4gICAgfVxyXG59KVxyXG5cclxuLypcclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG5cdE1ldGVvci5wdWJsaXNoKCdvYnMnLCBmdW5jdGlvbiAoKSB7XHJcblx0XHRyZXR1cm4gT2JzLmZpbmQoe30pIC8vIGhvdyB3ZSBwdWJsaXNoIGNvZGVzIHRvIHRoZSBjbGllbnQuIEZvciBub3csIGp1c3QgcmV0dXJuIGV2ZXJ5dGhpbmcuIFxyXG5cdH0pXHJcblxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xyXG4gICAgTWV0ZW9yLnN1YnNjcmliZSgnb2JzJykgLy8gTWFrZXMgdGhlIGNvbGxlY3Rpb24gYXZhaWxhYmxlIHRvIHRoZSBjbGllbnQgKFRlbXBsYXRlcyBhbmQgc3R1ZmYpXHJcbn07XHJcblxyXG5cclxuKi8iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9zZXJ2ZXIvZ2V0RGF0YS5qcydcbi8vaW1wb3J0IHsgT2JzIH0gZnJvbSAnLi4vaW1wb3J0cy9hcGkvT2JzZXJ2YXRpb25zLmpzJ1xuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxufSk7XG4iXX0=
